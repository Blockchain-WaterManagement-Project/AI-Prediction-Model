'''
from flask import Flask, render_template, redirect, url_for, request, session, flash, jsonify
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
from web3 import Web3

app = Flask(__name__)
app.secret_key = 'your_secret_key'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///water_quality.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(150), unique=True, nullable=False)
    password = db.Column(db.String(150), nullable=False)
    role = db.Column(db.String(50), nullable=False)

class WaterData(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    ph = db.Column(db.Float, nullable=False)
    color = db.Column(db.String(100), nullable=False)
    acidity = db.Column(db.Float, nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    validated = db.Column(db.Boolean, default=False)
    validator_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=True)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        user = User.query.filter_by(username=username).first()
        if user and check_password_hash(user.password, password):
            session['user_id'] = user.id
            session['username'] = user.username
            session['role'] = user.role
            print(f"Logged in as: {user.username}, Role: {user.role}")  # Debug line
            return redirect(url_for('dashboard'))
        else:
            flash('Invalid credentials')
    return render_template('login.html')

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        role = request.form['role']
        
        # Check if the username already exists
        existing_user = User.query.filter_by(username=username).first()
        if existing_user:
            flash('Username already exists. Please choose a different one.')
            return render_template('signup.html')
        
        hashed_password = generate_password_hash(password, method='pbkdf2:sha256')
        new_user = User(username=username, password=hashed_password, role=role)
        db.session.add(new_user)
        db.session.commit()
        flash('Signup successful! Please login.')
        return redirect(url_for('login'))
    return render_template('signup.html')

@app.route('/dashboard')
def dashboard():
    if 'username' in session:
        print(f"Dashboard for: {session['username']}, Role: {session['role']}")  # Debug line
        return render_template('dashboard.html', username=session['username'], role=session['role'])
    return redirect(url_for('login'))

@app.route('/logout')
def logout():
    print("Logging out...")  # Debug line
    session.pop('user_id', None)
    session.pop('username', None)
    session.pop('role', None)
    return redirect(url_for('login'))

@app.route('/create_water_data', methods=['GET', 'POST'])
def create_water_data():
    if 'username' in session and session['role'] == 'user':
        print(f"Creating water data for user: {session['username']}")  # Debug line
        if request.method == 'POST':
            ph = request.form['ph']
            color = request.form['color']
            acidity = request.form['acidity']
            new_data = WaterData(ph=ph, color=color, acidity=acidity, user_id=session['user_id'])
            db.session.add(new_data)
            db.session.commit()
            flash('Water data created successfully')
            return redirect(url_for('dashboard'))
        return render_template('create_water_data.html')
    return redirect(url_for('login'))

@app.route('/view_water_data')
def view_water_data():
    if 'username' in session and session['role'] == 'user':
        water_data = WaterData.query.filter_by(user_id=session['user_id']).all()
        print(f"Viewing water data for user: {session['username']}, Data: {water_data}")  # Debug line
        return render_template('view_water_data.html', water_data=water_data)
    return redirect(url_for('login'))

@app.route('/manage_users')
def manage_users():
    if 'username' in session and session['role'] == 'admin':
        users = User.query.all()
        print(f"Managing users, Admin: {session['username']}, Users: {users}")  # Debug line
        return render_template('manage_users.html', users=users)
    return redirect(url_for('login'))

@app.route('/validate_data')
def validate_data():
    if 'username' in session and session['role'] == 'government':
        water_data = WaterData.query.filter_by(validated=False).all()
        print(f"Validating data, Government: {session['username']}, Data: {water_data}")  # Debug line
        return render_template('validate_data.html', water_data=water_data)
    return redirect(url_for('login'))

@app.route('/validate/<int:data_id>', methods=['POST'])
def validate(data_id):
    if 'username' in session and session['role'] == 'government':
        data = WaterData.query.get_or_404(data_id)
        data.validated = True
        data.validator_id = session['user_id']
        user = User.query.get(data.user_id)
        flash(f'Data validated successfully. User {user.username} has been incentivized.')
        db.session.commit()
        return redirect(url_for('validate_data'))
    return redirect(url_for('login'))

@app.route('/validate_with_metamask', methods=['POST'])
def validate_with_metamask():
    # Handle MetaMask validation process
    data_id = request.form['data_id']
    data = WaterData.query.get_or_404(data_id)
    data.validated = True
    data.validator_id = session['user_id']
    user = User.query.get(data.user_id)
    flash(f'Data validated successfully. User {user.username} has been incentivized.')
    db.session.commit()
    return redirect(url_for('validate_data'))

@app.route('/about_us')
def about_us():
    return 'About Us Page'

@app.route('/email_us')
def email_us():
    return 'Email Us Page'

@app.route('/water_supply')
def water_supply():
    return 'Water Supply Page'

@app.route('/water_consumers')
def water_consumers():
    return 'Water Consumers Page'

@app.route('/water_treatment')
def water_treatment():
    return 'Water Treatment Page'

@app.route('/water_discharge')
def water_discharge():
    return 'Water Discharge Page'

if __name__ == '__main__':
    # Create the database tables
    with app.app_context():
        db.create_all()
    app.run(debug=True)ANOTHER ONE 

from flask import Flask, render_template, redirect, url_for, request, session, flash
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.secret_key = 'your_secret_key'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///water_quality.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(150), unique=True, nullable=False)
    password = db.Column(db.String(150), nullable=False)
    role = db.Column(db.String(50), nullable=False)

class WaterData(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    ph = db.Column(db.Float, nullable=False)
    color = db.Column(db.String(100), nullable=False)
    acidity = db.Column(db.Float, nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    validated = db.Column(db.Boolean, default=False)
    validator_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=True)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        user = User.query.filter_by(username=username).first()
        if user and check_password_hash(user.password, password):
            session['user_id'] = user.id
            session['username'] = user.username
            session['role'] = user.role
            return redirect(url_for('dashboard'))
        else:
            flash('Invalid credentials')
    return render_template('login.html')

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        role = request.form['role']
        
        existing_user = User.query.filter_by(username=username).first()
        if existing_user:
            flash('Username already exists. Please choose a different one.')
            return render_template('signup.html')
        
        hashed_password = generate_password_hash(password, method='pbkdf2:sha256')
        new_user = User(username=username, password=hashed_password, role=role)
        db.session.add(new_user)
        db.session.commit()
        flash('Signup successful! Please login.')
        return redirect(url_for('login'))
    return render_template('signup.html')

@app.route('/dashboard')
def dashboard():
    if 'username' in session:
        return render_template('dashboard.html', username=session['username'], role=session['role'])
    return redirect(url_for('login'))

@app.route('/logout')
def logout():
    session.pop('user_id', None)
    session.pop('username', None)
    session.pop('role', None)
    return redirect(url_for('login'))

@app.route('/create_water_data', methods=['GET', 'POST'])
def create_water_data():
    if 'username' in session and session['role'] == 'user':
        if request.method == 'POST':
            ph = float(request.form['ph'])
            color = request.form['color']
            acidity = float(request.form['acidity'])
            negative_values = ph < 0 or acidity < 0

            new_data = WaterData(ph=ph, color=color, acidity=acidity, user_id=session['user_id'])
            db.session.add(new_data)
            db.session.commit()

            if negative_values:
                flash('Data created with negative values. You will need to pay a penalty if validated.')
            else:
                flash('Data created successfully. Awaiting validation.')

            return redirect(url_for('dashboard'))
        return render_template('create_water_data.html')
    return redirect(url_for('login'))

@app.route('/view_water_data')
def view_water_data():
    if 'username' in session and session['role'] == 'user':
        water_data = WaterData.query.filter_by(user_id=session['user_id']).all()
        return render_template('view_water_data.html', water_data=water_data)
    return redirect(url_for('login'))

@app.route('/manage_users')
def manage_users():
    if 'username' in session and session['role'] == 'admin':
        users = User.query.all()
        return render_template('manage_users.html', users=users)
    return redirect(url_for('login'))

@app.route('/validate_data')
def validate_data():
    if 'username' in session and session['role'] == 'government':
        water_data = WaterData.query.filter_by(validated=False).all()
        return render_template('validate_data.html', water_data=water_data)
    return redirect(url_for('login'))

@app.route('/validate_with_metamask', methods=['POST'])
def validate_with_metamask():
    if 'username' in session and session['role'] == 'government':
        data_id = request.form.get('data_id')
        data = WaterData.query.get_or_404(data_id)
        data.validated = True
        data.validator_id = session['user_id']
        db.session.commit()
        return '', 200
    return '', 403

@app.route('/validate/<int:data_id>')
def validate(data_id):
    if 'username' in session and session['role'] == 'government':
        data = WaterData.query.get_or_404(data_id)
        data.validated = True
        data.validator_id = session['user_id']
        user = User.query.get(data.user_id)
        flash(f'Data validated successfully. User {user.username} has been incentivized.')
        db.session.commit()
        return redirect(url_for('validate_data'))
    return redirect(url_for('login'))

@app.route('/about_us')
def about_us():
    return 'About Us Page'

@app.route('/email_us')
def email_us():
    return 'Email Us Page'

@app.route('/water_supply')
def water_supply():
    return 'Water Supply Page'

@app.route('/water_consumers')
def water_consumers():
    return 'Water Consumers Page'

@app.route('/water_treatment')
def water_treatment():
    return 'Water Treatment Page'

@app.route('/water_discharge')
def water_discharge():
    return 'Water Discharge Page'

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(debug=True)

    ANOTHER ONE

from flask import Flask, render_template, redirect, url_for, request, session, flash, jsonify
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime
from web3 import Web3
import os

app = Flask(__name__)
app.secret_key = 'your_secret_key'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///water_quality.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)
migrate = Migrate(app, db)

# Connect to Ethereum Mainnet
alchemy_url = "https://eth-mainnet.g.alchemy.com/v2/3OqltayCdWx7230AEE3WNjtBp-xdAqoN"
web3 = Web3(Web3.HTTPProvider(alchemy_url))

# Connect to Sepolia Test Network
sepolia_rpc_url = "https://sepolia-testnet-rpc.com"
web3_sepolia = Web3(Web3.HTTPProvider(sepolia_rpc_url))

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(150), unique=True, nullable=False)
    password = db.Column(db.String(150), nullable=False)
    role = db.Column(db.String(50), nullable=False)

class WaterData(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    ph = db.Column(db.Float, nullable=False)
    color = db.Column(db.String(100), nullable=False)
    acidity = db.Column(db.Float, nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    validated = db.Column(db.Boolean, default=False)
    validator_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=True)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)

class Transaction(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    transaction_type = db.Column(db.String(50), nullable=False)
    amount = db.Column(db.Float, nullable=False)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        user = User.query.filter_by(username=username).first()
        if user and check_password_hash(user.password, password):
            session['user_id'] = user.id
            session['username'] = user.username
            session['role'] = user.role
            return redirect(url_for('dashboard'))
        else:
            flash('Invalid credentials')
    return render_template('login.html')

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        role = request.form['role']
        
        existing_user = User.query.filter_by(username=username).first()
        if existing_user:
            flash('Username already exists. Please choose a different one.')
            return render_template('signup.html')
        
        hashed_password = generate_password_hash(password, method='pbkdf2:sha256')
        new_user = User(username=username, password=hashed_password, role=role)
        db.session.add(new_user)
        db.session.commit()
        flash('Signup successful! Please login.')
        return redirect(url_for('login'))
    return render_template('signup.html')

@app.route('/dashboard')
def dashboard():
    if 'username' in session:
        return render_template('dashboard.html', username=session['username'], role=session['role'])
    return redirect(url_for('login'))

@app.route('/logout')
def logout():
    session.pop('user_id', None)
    session.pop('username', None)
    session.pop('role', None)
    return redirect(url_for('login'))

@app.route('/create_water_data', methods=['GET', 'POST'])
def create_water_data():
    if 'username' in session and session['role'] == 'user':
        if request.method == 'POST':
            ph = float(request.form['ph'])
            color = request.form['color']
            acidity = float(request.form['acidity'])
            negative_values = ph < 0 or acidity < 0

            new_data = WaterData(ph=ph, color=color, acidity=acidity, user_id=session['user_id'])
            db.session.add(new_data)
            db.session.commit()

            if negative_values:
                flash('Data created with negative values. You will need to pay a penalty if validated.')
            else:
                flash('Data created successfully. Awaiting validation.')

            return redirect(url_for('dashboard'))
        return render_template('create_water_data.html')
    return redirect(url_for('login'))

@app.route('/view_water_data')
def view_water_data():
    if 'username' in session and session['role'] == 'user':
        water_data = WaterData.query.filter_by(user_id=session['user_id']).all()
        transactions = Transaction.query.filter_by(user_id=session['user_id']).all()

        # Get validator information
        validator_usernames = {}
        for data in water_data:
            if data.validator_id:
                validator = User.query.get(data.validator_id)
                if validator:
                    validator_usernames[data.validator_id] = validator.username

        return render_template('view_water_data.html', water_data=water_data, transactions=transactions, validator_usernames=validator_usernames)
    return redirect(url_for('login'))

@app.route('/manage_users')
def manage_users():
    if 'username' in session and session['role'] == 'admin':
        users = User.query.all()
        return render_template('manage_users.html', users=users)
    return redirect(url_for('login'))

@app.route('/validate_data')
def validate_data():
    if 'username' in session and session['role'] == 'government':
        water_data = WaterData.query.filter_by(validated=False).all()
        return render_template('validate_data.html', water_data=water_data)
    return redirect(url_for('login'))

@app.route('/validate_with_metamask', methods=['POST'])
def validate_with_metamask():
    if 'username' in session and session['role'] == 'government':
        data_id = request.form.get('data_id')
        data = WaterData.query.get_or_404(data_id)
        data.validated = True
        data.validator_id = session['user_id']
        db.session.commit()
        return '', 200
    return '', 403

@app.route('/validate/<int:data_id>')
def validate(data_id):
    if 'username' in session and session['role'] == 'government':
        data = WaterData.query.get_or_404(data_id)
        data.validated = True
        data.validator_id = session['user_id']
        user = User.query.get(data.user_id)
        
        # Create an incentive transaction
        incentive_amount = 0.00000034  # Incentive amount in ETH
        tx = {
            'to': ACCOUNT.address,
            'value': web3.toWei(incentive_amount, 'ether'),
            'gas': 2000000,
            'gasPrice': web3.toWei('20', 'gwei'),
            'nonce': web3.eth.getTransactionCount(ACCOUNT.address),
        }
        signed_tx = web3.eth.account.sign_transaction(tx, PRIVATE_KEY)
        tx_hash = web3.eth.sendRawTransaction(signed_tx.rawTransaction)

        # Add incentive transaction to database
        incentive_transaction = Transaction(user_id=user.id, transaction_type='incentive', amount=incentive_amount)
        db.session.add(incentive_transaction)
        db.session.commit()

        flash(f'Data validated successfully. User {user.username} has been incentivized. Transaction hash: {web3.toHex(tx_hash)}')
        return redirect(url_for('validate_data'))
    return redirect(url_for('login'))

@app.route('/apply_penalty', methods=['POST'])
def apply_penalty():
    if 'username' in session and session['role'] == 'government':
        recipient_address = request.form.get('recipient_address')
        
        penalty_amount = 0.0000057  # Penalty amount in ETH
        tx = {
            'to': recipient_address,
            'value': web3.toWei(penalty_amount, 'ether'),
            'gas': 2000000,
            'gasPrice': web3.toWei('20', 'gwei'),
            'nonce': web3.eth.getTransactionCount(ACCOUNT.address),
        }
        signed_tx = web3.eth.account.sign_transaction(tx, PRIVATE_KEY)
        tx_hash = web3.eth.sendRawTransaction(signed_tx.rawTransaction)
        
        # Add penalty transaction to database
        penalty_transaction = Transaction(user_id=session['user_id'], transaction_type='penalty', amount=penalty_amount)
        db.session.add(penalty_transaction)
        db.session.commit()

        return jsonify({'tx_hash': web3.toHex(tx_hash)})
    return '', 403

@app.route('/apply_validation', methods=['POST'])
def apply_validation():
    if 'username' in session and session['role'] == 'government':
        recipient_address = request.form.get('recipient_address')
        
        validate_amount = 0.000004  # Validation amount in ETH
        tx = {
            'to': recipient_address,
            'value': web3.toWei(validate_amount, 'ether'),
            'gas': 2000000,
            'gasPrice': web3.toWei('20', 'gwei'),
            'nonce': web3.eth.getTransactionCount(ACCOUNT.address),
        }
        signed_tx = web3.eth.account.sign_transaction(tx, PRIVATE_KEY)
        tx_hash = web3.eth.sendRawTransaction(signed_tx.rawTransaction)
        
        return jsonify({'tx_hash': web3.toHex(tx_hash)})
    return '', 403

@app.route('/about_us')
def about_us():
    return render_template('about_us.html')

@app.route('/email_us')
def email_us():
    return render_template('email_us.html')

@app.route('/water_supply')
def water_supply():
    return render_template('water_supply.html')

@app.route('/water_demand')
def water_demand():
    return render_template('water_demand.html')

@app.route('/water_consumers')
def water_consumers():
    return render_template('water_consumers.html')

@app.route('/water_treatment')
def water_treatment():
    return render_template('water_treatment.html')

@app.route('/water_discharge')
def water_discharge():
    return render_template('water_discharge.html')


if __name__ == '__main__':
    app.run(debug=True)



from flask import Flask, render_template, redirect, url_for, request, session, flash, jsonify
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime
from web3 import Web3
import os

app = Flask(__name__)
app.secret_key = 'your_secret_key'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///water_quality.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)
migrate = Migrate(app, db)

# Connect to Ethereum Mainnet
alchemy_url = "https://eth-mainnet.g.alchemy.com/v2/3OqltayCdWx7230AEE3WNjtBp-xdAqoN"
web3 = Web3(Web3.HTTPProvider(alchemy_url))

# Connect to Sepolia Test Network
sepolia_rpc_url = "https://sepolia-testnet-rpc.com"
web3_sepolia = Web3(Web3.HTTPProvider(sepolia_rpc_url))

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(150), unique=True, nullable=False)
    password = db.Column(db.String(150), nullable=False)
    role = db.Column(db.String(50), nullable=False)

class WaterData(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    ph = db.Column(db.Float, nullable=False)
    color = db.Column(db.String(100), nullable=False)
    acidity = db.Column(db.Float, nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    validated = db.Column(db.Boolean, default=False)
    validator_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=True)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)
    transaction_hash = db.Column(db.String(100), nullable=True)
    amount_sent = db.Column(db.Float, nullable=True)
    amount_received = db.Column(db.Float, nullable=True)

class Transaction(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    transaction_type = db.Column(db.String(50), nullable=False)
    amount = db.Column(db.Float, nullable=False)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        user = User.query.filter_by(username=username).first()
        if user and check_password_hash(user.password, password):
            session['user_id'] = user.id
            session['username'] = user.username
            session['role'] = user.role
            return redirect(url_for('dashboard'))
        else:
            flash('Invalid credentials')
    return render_template('login.html')

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        role = request.form['role']
        
        existing_user = User.query.filter_by(username=username).first()
        if existing_user:
            flash('Username already exists. Please choose a different one.')
            return render_template('signup.html')
        
        hashed_password = generate_password_hash(password, method='pbkdf2:sha256')
        new_user = User(username=username, password=hashed_password, role=role)
        db.session.add(new_user)
        db.session.commit()
        flash('Signup successful! Please login.')
        return redirect(url_for('login'))
    return render_template('signup.html')

@app.route('/dashboard')
def dashboard():
    if 'username' in session:
        return render_template('dashboard.html', username=session['username'], role=session['role'])
    return redirect(url_for('login'))

@app.route('/logout')
def logout():
    session.pop('user_id', None)
    session.pop('username', None)
    session.pop('role', None)
    return redirect(url_for('login'))

@app.route('/create_water_data', methods=['GET', 'POST'])
def create_water_data():
    if 'username' in session and session['role'] == 'user':
        if request.method == 'POST':
            ph = float(request.form['ph'])
            color = request.form['color']
            acidity = float(request.form['acidity'])
            negative_values = ph < 0 or acidity < 0

            new_data = WaterData(ph=ph, color=color, acidity=acidity, user_id=session['user_id'])
            db.session.add(new_data)
            db.session.commit()

            if negative_values:
                flash('Data created with negative values. You will need to pay a penalty if validated.')
            else:
                flash('Data created successfully. Awaiting validation.')

            return redirect(url_for('dashboard'))
        return render_template('create_water_data.html')
    return redirect(url_for('login'))

@app.route('/view_water_data')
def view_water_data():
    if 'username' in session and session['role'] == 'user':
        water_data = WaterData.query.filter_by(user_id=session['user_id']).all()
        transactions = Transaction.query.filter_by(user_id=session['user_id']).all()

        # Get validator information
        validator_usernames = {}
        for data in water_data:
            if data.validator_id:
                validator = User.query.get(data.validator_id)
                if validator:
                    validator_usernames[data.validator_id] = validator.username

        return render_template('view_water_data.html', water_data=water_data, transactions=transactions, validator_usernames=validator_usernames)
    return redirect(url_for('login'))

@app.route('/manage_users')
def manage_users():
    if 'username' in session and session['role'] == 'admin':
        users = User.query.all()
        return render_template('manage_users.html', users=users)
    return redirect(url_for('login'))

@app.route('/validate_data')
def validate_data():
    if 'username' in session and session['role'] == 'government':
        water_data = WaterData.query.filter_by(validated=False).all()
        return render_template('validate_data.html', water_data=water_data)
    return redirect(url_for('login'))

@app.route('/validate_with_metamask', methods=['POST'])
def validate_with_metamask():
    if 'username' in session and session['role'] == 'government':
        data_id = request.form.get('data_id')
        transaction_hash = request.form.get('transaction_hash')
        amount_sent = request.form.get('amount_sent')
        amount_received = request.form.get('amount_received')

        data = WaterData.query.get_or_404(data_id)
        data.validated = True
        data.validator_id = session['user_id']
        data.transaction_hash = transaction_hash
        data.amount_sent = amount_sent
        data.amount_received = amount_received
        db.session.commit()
        return jsonify({'success': True})
    return '', 403

@app.route('/validate/<int:data_id>')
def validate(data_id):
    if 'username' in session and session['role'] == 'government':
        data = WaterData.query.get_or_404(data_id)
        data.validated = True
        data.validator_id = session['user_id']
        user = User.query.get(data.user_id)
        
        # Create an incentive transaction
        incentive_amount = 0.00000034  # Incentive amount in ETH
        tx = {
            'to': ACCOUNT.address,
            'value': web3.toWei(incentive_amount, 'ether'),
            'gas': 2000000,
            'gasPrice': web3.toWei('20', 'gwei'),
            'nonce': web3.eth.getTransactionCount(ACCOUNT.address),
        }
        signed_tx = web3.eth.account.sign_transaction(tx, PRIVATE_KEY)
        tx_hash = web3.eth.sendRawTransaction(signed_tx.rawTransaction)

        # Add incentive transaction to database
        incentive_transaction = Transaction(user_id=user.id, transaction_type='incentive', amount=incentive_amount)
        db.session.add(incentive_transaction)
        db.session.commit()

        flash(f'Data validated successfully. User {user.username} has been incentivized. Transaction hash: {web3.toHex(tx_hash)}')
        return redirect(url_for('validate_data'))
    return redirect(url_for('login'))

@app.route('/apply_penalty', methods=['POST'])
def apply_penalty():
    if 'username' in session and session['role'] == 'government':
        recipient_address = request.form.get('recipient_address')
        
        penalty_amount = 0.0000057  # Penalty amount in ETH
        tx = {
            'to': recipient_address,
            'value': web3.toWei(penalty_amount, 'ether'),
            'gas': 2000000,
            'gasPrice': web3.toWei('20', 'gwei'),
            'nonce': web3.eth.getTransactionCount(ACCOUNT.address),
        }
        signed_tx = web3.eth.account.sign_transaction(tx, PRIVATE_KEY)
        tx_hash = web3.eth.sendRawTransaction(signed_tx.rawTransaction)
        
        # Add penalty transaction to database
        penalty_transaction = Transaction(user_id=session['user_id'], transaction_type='penalty', amount=penalty_amount)
        db.session.add(penalty_transaction)
        db.session.commit()

        return jsonify({'tx_hash': web3.toHex(tx_hash)})
    return '', 403

@app.route('/apply_validation', methods=['POST'])
def apply_validation():
    if 'username' in session and session['role'] == 'government':
        data_id = request.form.get('data_id')
        data = WaterData.query.get(data_id)
        data.validated = True
        data.validator_id = session['user_id']

        # Add validation transaction to database
        validation_transaction = Transaction(user_id=session['user_id'], transaction_type='validation', amount=0)
        db.session.add(validation_transaction)
        db.session.commit()
        
        return redirect(url_for('validate_data'))
    return '', 403


@app.route('/about_us')
def about_us():
    return render_template('about_us.html')

@app.route('/email_us')
def email_us():
    return render_template('email_us.html')

@app.route('/water_supply')
def water_supply():
    return render_template('water_supply.html')

@app.route('/water_demand')
def water_demand():
    return render_template('water_demand.html')

@app.route('/water_consumers')
def water_consumers():
    return render_template('water_consumers.html')

@app.route('/water_treatment')
def water_treatment():
    return render_template('water_treatment.html')

@app.route('/water_discharge')
def water_discharge():
    return render_template('water_discharge.html')

if __name__ == '__main__':
    app.run(debug=True)

    
from flask import Flask, render_template, redirect, url_for, request, session, flash, jsonify
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime
from web3 import Web3
import os

app = Flask(__name__)
app.secret_key = os.environ.get('SECRET_KEY', 'your_secret_key')  # Use environment variables for sensitive data
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///water_quality.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)
migrate = Migrate(app, db)

# Connect to Ethereum Mainnet and Sepolia Test Network
alchemy_url = "https://eth-mainnet.g.alchemy.com/v2/3OqltayCdWx7230AEE3WNjtBp-xdAqoN"
web3 = Web3(Web3.HTTPProvider(alchemy_url))

sepolia_rpc_url = "https://sepolia-testnet-rpc.com"
web3_sepolia = Web3(Web3.HTTPProvider(sepolia_rpc_url))


class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(150), unique=True, nullable=False)
    password = db.Column(db.String(150), nullable=False)
    role = db.Column(db.String(50), nullable=False)

class WaterData(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    ph = db.Column(db.Float, nullable=False)
    color = db.Column(db.String(100), nullable=False)
    acidity = db.Column(db.Float, nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    validated = db.Column(db.Boolean, default=False)
    validator_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=True)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)
    transaction_hash = db.Column(db.String(100), nullable=True)
    amount_sent = db.Column(db.Float, nullable=True)
    amount_received = db.Column(db.Float, nullable=True)

class Transaction(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    transaction_type = db.Column(db.String(50), nullable=False)
    amount = db.Column(db.Float, nullable=False)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        user = User.query.filter_by(username=username).first()
        if user and check_password_hash(user.password, password):
            session['user_id'] = user.id
            session['username'] = user.username
            session['role'] = user.role
            return redirect(url_for('dashboard'))
        else:
            flash('Invalid credentials')
    return render_template('login.html')

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        role = request.form['role']

        existing_user = User.query.filter_by(username=username).first()
        if existing_user:
            flash('Username already exists. Please choose a different one.')
            return render_template('signup.html')

        hashed_password = generate_password_hash(password, method='pbkdf2:sha256')
        new_user = User(username=username, password=hashed_password, role=role)
        db.session.add(new_user)
        db.session.commit()
        flash('Signup successful! Please login.')
        return redirect(url_for('login'))
    return render_template('signup.html')

@app.route('/dashboard')
def dashboard():
    if 'username' in session:
        return render_template('dashboard.html', username=session['username'], role=session['role'])
    return redirect(url_for('login'))

@app.route('/logout')
def logout():
    session.clear()  # Clear entire session
    return redirect(url_for('login'))

@app.route('/create_water_data', methods=['GET', 'POST'])
def create_water_data():
    if 'username' in session and session['role'] == 'user':
        if request.method == 'POST':
            ph = float(request.form['ph'])
            color = request.form['color']
            acidity = float(request.form['acidity'])
            negative_values = ph < 0 or acidity < 0

            new_data = WaterData(ph=ph, color=color, acidity=acidity, user_id=session['user_id'])
            db.session.add(new_data)
            db.session.commit()

            if negative_values:
                flash('Data created with negative values. You will need to pay a penalty if validated.')
            else:
                flash('Data created successfully. Awaiting validation.')

            return redirect(url_for('dashboard'))
        return render_template('create_water_data.html')
    return redirect(url_for('login'))

@app.route('/view_water_data')
def view_water_data():
    if 'username' in session and session['role'] == 'user':
        water_data = WaterData.query.filter_by(user_id=session['user_id']).all()
        transactions = Transaction.query.filter_by(user_id=session['user_id']).all()

        # Get validator information
        validator_usernames = {data.validator_id: User.query.get(data.validator_id).username for data in water_data if data.validator_id}

        return render_template('view_water_data.html', water_data=water_data, transactions=transactions, validator_usernames=validator_usernames)
    return redirect(url_for('login'))

@app.route('/manage_users')
def manage_users():
    if 'username' in session and session['role'] == 'admin':
        users = User.query.all()
        return render_template('manage_users.html', users=users)
    return redirect(url_for('login'))

@app.route('/validate_data')
def validate_data():
    if 'username' in session and session['role'] == 'government':
        water_data = WaterData.query.filter_by(validated=False).all()
        return render_template('validate_data.html', water_data=water_data)
    return redirect(url_for('login'))

@app.route('/validate_with_metamask', methods=['POST'])
def validate_with_metamask():
    if 'username' in session and session['role'] == 'government':
        data_id = request.form.get('data_id')
        transaction_hash = request.form.get('transaction_hash')
        amount_sent = float(request.form.get('amount_sent', 0))
        amount_received = float(request.form.get('amount_received', 0))

        data = WaterData.query.get_or_404(data_id)
        data.validated = True
        data.validator_id = session['user_id']
        data.transaction_hash = transaction_hash
        data.amount_sent = amount_sent
        data.amount_received = amount_received
        db.session.commit()
        return jsonify({'success': True})
    return '', 403

@app.route('/validate/<int:data_id>')
def validate(data_id):
    if 'username' in session and session['role'] == 'government':
        data = WaterData.query.get_or_404(data_id)
        data.validated = True
        data.validator_id = session['user_id']
        user = User.query.get(data.user_id)

        # Ethereum account and key
        ACCOUNT = web3.eth.account.privateKeyToAccount(os.environ.get('PRIVATE_KEY'))
        
        # Create an incentive transaction
        incentive_amount = 0.00000034  # Incentive amount in ETH
        tx = {
            'to': ACCOUNT.address,
            'value': web3.toWei(incentive_amount, 'ether'),
            'gas': 2000000,
            'gasPrice': web3.toWei('20', 'gwei'),
            'nonce': web3.eth.getTransactionCount(ACCOUNT.address),
        }
        signed_tx = web3.eth.account.sign_transaction(tx, os.environ.get('PRIVATE_KEY'))
        tx_hash = web3.eth.sendRawTransaction(signed_tx.rawTransaction)

        # Add incentive transaction to database
        incentive_transaction = Transaction(user_id=user.id, transaction_type='incentive', amount=incentive_amount)
        db.session.add(incentive_transaction)
        db.session.commit()

        flash(f'Data validated successfully. User {user.username} has been incentivized. Transaction hash: {web3.toHex(tx_hash)}')
        return redirect(url_for('validate_data'))
    return redirect(url_for('login'))

@app.route('/apply_penalty', methods=['POST'])
def apply_penalty():
    if 'username' in session and session['role'] == 'government':
        recipient_address = request.form.get('recipient_address')

        # Ethereum account and key
        ACCOUNT = web3.eth.account.privateKeyToAccount(os.environ.get('PRIVATE_KEY'))

        penalty_amount = 0.0000057  # Penalty amount in ETH
        tx = {
            'to': recipient_address,
            'value': web3.toWei(penalty_amount, 'ether'),
            'gas': 2000000,
            'gasPrice': web3.toWei('20', 'gwei'),
            'nonce': web3.eth.getTransactionCount(ACCOUNT.address),
        }
        signed_tx = web3.eth.account.sign_transaction(tx, os.environ.get('PRIVATE_KEY'))
        tx_hash = web3.eth.sendRawTransaction(signed_tx.rawTransaction)

        penalty_transaction = Transaction(user_id=session['user_id'], transaction_type='penalty', amount=penalty_amount)
        db.session.add(penalty_transaction)
        db.session.commit()

        return jsonify({'success': True, 'tx_hash': web3.toHex(tx_hash)})

    return jsonify({'success': False, 'error': 'Unauthorized'}), 403

@app.route('/update_water_data', methods=['GET', 'POST'])
def update_water_data():
    if request.method == 'POST':
        # Handle form submission
        pass
    return render_template('update_water_data.html')


@app.route('/query_water_data')
def query_water_data():
    return render_template('query_water_data.html')

@app.route('/delete_water_data', methods=['POST'])
def delete_water_data():
    # Handle data deletion
    return redirect(url_for('dashboard'))



@app.route('/about_us')
def about_us():
    return render_template('about_us.html')

@app.route('/email_us')
def email_us():
    return render_template('email_us.html')

@app.route('/water_supply')
def water_supply():
    return render_template('water_supply.html')

@app.route('/water_demand')
def water_demand():
    return render_template('water_demand.html')

@app.route('/water_consumers')
def water_consumers():
    return render_template('water_consumers.html')

@app.route('/water_treatment')
def water_treatment():
    return render_template('water_treatment.html')

@app.route('/water_discharge')
def water_discharge():
    return render_template('water_discharge.html')

if __name__ == '__main__':
    app.run(debug=True)

from flask import Flask, render_template, redirect, url_for, request, session, flash, jsonify
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime
from web3 import Web3
import os

app = Flask(__name__)
app.secret_key = os.environ.get('SECRET_KEY', 'your_secret_key')  # Use environment variables for sensitive data
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///water_quality.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)
migrate = Migrate(app, db)

# Connect to Ethereum Mainnet and Sepolia Test Network
alchemy_url = "https://eth-mainnet.g.alchemy.com/v2/3OqltayCdWx7230AEE3WNjtBp-xdAqoN"
web3 = Web3(Web3.HTTPProvider(alchemy_url))

sepolia_rpc_url = "https://sepolia-testnet-rpc.com"
web3_sepolia = Web3(Web3.HTTPProvider(sepolia_rpc_url))


class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(150), unique=True, nullable=False)
    password = db.Column(db.String(150), nullable=False)
    role = db.Column(db.String(50), nullable=False)

class WaterData(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    ph = db.Column(db.Float, nullable=False)
    color = db.Column(db.String(100), nullable=False)
    acidity = db.Column(db.Float, nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    validated = db.Column(db.Boolean, default=False)
    validator_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=True)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)
    transaction_hash = db.Column(db.String(100), nullable=True)
    amount_sent = db.Column(db.Float, nullable=True)
    amount_received = db.Column(db.Float, nullable=True)

class Transaction(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    transaction_type = db.Column(db.String(50), nullable=False)
    amount = db.Column(db.Float, nullable=False)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        user = User.query.filter_by(username=username).first()
        if user and check_password_hash(user.password, password):
            session['user_id'] = user.id
            session['username'] = user.username
            session['role'] = user.role
            return redirect(url_for('dashboard'))
        else:
            flash('Invalid credentials')
    return render_template('login.html')

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        role = request.form['role']

        existing_user = User.query.filter_by(username=username).first()
        if existing_user:
            flash('Username already exists. Please choose a different one.')
            return render_template('signup.html')

        hashed_password = generate_password_hash(password, method='pbkdf2:sha256')
        new_user = User(username=username, password=hashed_password, role=role)
        db.session.add(new_user)
        db.session.commit()
        flash('Signup successful! Please login.')
        return redirect(url_for('login'))
    return render_template('signup.html')

@app.route('/dashboard')
def dashboard():
    if 'username' in session:
        return render_template('dashboard.html', 
                               username=session['username'], 
                               role=session['role'])
    return redirect(url_for('login'))


@app.route('/logout')
def logout():
    session.clear()  # Clear entire session
    return redirect(url_for('login'))

@app.route('/create_water_data', methods=['GET', 'POST'])
def create_water_data():
    if 'username' in session and session['role'] == 'user':
        if request.method == 'POST':
            ph = float(request.form['ph'])
            color = request.form['color']
            acidity = float(request.form['acidity'])
            negative_values = ph < 0 or acidity < 0

            new_data = WaterData(ph=ph, color=color, acidity=acidity, user_id=session['user_id'])
            db.session.add(new_data)
            db.session.commit()

            if negative_values:
                flash('Data created with negative values. You will need to pay a penalty if validated.')
            else:
                flash('Data created successfully. Awaiting validation.')

            return redirect(url_for('dashboard'))
        return render_template('create_water_data.html')
    return redirect(url_for('login'))

@app.route('/view_water_data')
def view_water_data():
    if 'username' in session and session['role'] == 'user':
        water_data = WaterData.query.filter_by(user_id=session['user_id']).all()
        transactions = Transaction.query.filter_by(user_id=session['user_id']).all()

        # Get validator information
        validator_usernames = {data.validator_id: User.query.get(data.validator_id).username for data in water_data if data.validator_id}

        return render_template('view_water_data.html', water_data=water_data, transactions=transactions, validator_usernames=validator_usernames)
    return redirect(url_for('login'))

@app.route('/manage_users')
def manage_users():
    if 'username' in session and session['role'] == 'admin':
        users = User.query.all()
        return render_template('manage_users.html', users=users)
    return redirect(url_for('login'))

@app.route('/validate_data')
def validate_data():
    if 'username' in session and session['role'] == 'government':
        water_data = WaterData.query.filter_by(validated=False).all()
        return render_template('validate_data.html', water_data=water_data)
    return redirect(url_for('login'))

@app.route('/validate_with_metamask', methods=['POST'])
def validate_with_metamask():
    if 'username' in session and session['role'] == 'government':
        data_id = request.form.get('data_id')
        transaction_hash = request.form.get('transaction_hash')
        amount_sent = float(request.form.get('amount_sent', 0))
        amount_received = float(request.form.get('amount_received', 0))

        data = WaterData.query.get_or_404(data_id)
        data.validated = True
        data.validator_id = session['user_id']
        data.transaction_hash = transaction_hash
        data.amount_sent = amount_sent
        data.amount_received = amount_received
        db.session.commit()
        return jsonify({'success': True})
    return '', 403

@app.route('/validate/<int:data_id>')
def validate(data_id):
    if 'username' in session and session['role'] == 'government':
        data = WaterData.query.get_or_404(data_id)
        data.validated = True
        data.validator_id = session['user_id']
        user = User.query.get(data.user_id)

        # Ethereum account and key
        ACCOUNT = web3.eth.account.privateKeyToAccount(os.environ.get('PRIVATE_KEY'))
        
        # Create an incentive transaction
        incentive_amount = 0.00000034  # Incentive amount in ETH
        tx = {
            'to': ACCOUNT.address,
            'value': web3.toWei(incentive_amount, 'ether'),
            'gas': 2000000,
            'gasPrice': web3.toWei('20', 'gwei'),
            'nonce': web3.eth.getTransactionCount(ACCOUNT.address),
        }
        signed_tx = web3.eth.account.sign_transaction(tx, os.environ.get('PRIVATE_KEY'))
        tx_hash = web3.eth.sendRawTransaction(signed_tx.rawTransaction)

        # Add incentive transaction to database
        incentive_transaction = Transaction(user_id=user.id, transaction_type='incentive', amount=incentive_amount)
        db.session.add(incentive_transaction)
        db.session.commit()

        flash(f'Data validated successfully. User {user.username} has been incentivized. Transaction hash: {web3.toHex(tx_hash)}')
        return redirect(url_for('validate_data'))
    return redirect(url_for('login'))

@app.route('/apply_penalty', methods=['POST'])
def apply_penalty():
    if 'username' in session and session['role'] == 'government':
        recipient_address = request.form.get('recipient_address')

        # Ethereum account and key
        ACCOUNT = web3.eth.account.privateKeyToAccount(os.environ.get('PRIVATE_KEY'))

        penalty_amount = 0.0000057  # Penalty amount in ETH
        tx = {
            'to': recipient_address,
            'value': web3.toWei(penalty_amount, 'ether'),
            'gas': 2000000,
            'gasPrice': web3.toWei('20', 'gwei'),
            'nonce': web3.eth.getTransactionCount(ACCOUNT.address),
        }
        signed_tx = web3.eth.account.sign_transaction(tx, os.environ.get('PRIVATE_KEY'))
        tx_hash = web3.eth.sendRawTransaction(signed_tx.rawTransaction)

        penalty_transaction = Transaction(user_id=session['user_id'], transaction_type='penalty', amount=penalty_amount)
        db.session.add(penalty_transaction)
        db.session.commit()

        flash(f'Penalty applied successfully. Transaction hash: {web3.toHex(tx_hash)}')
        return jsonify({'success': True})
    return jsonify({'success': False, 'message': 'Unauthorized'}), 403

@app.route('/check_connection')
def check_connection():
    if 'username' in session:
        is_connected = web3.isConnected() and web3_sepolia.isConnected()
        mainnet_block_number = web3.eth.block_number if is_connected else 'N/A'
        sepolia_block_number = web3_sepolia.eth.block_number if is_connected else 'N/A'

        # Fetch balance
        user_address = os.environ.get('USER_ADDRESS')  # Environment variable for security
        balance_mainnet = web3.eth.get_balance(user_address) if is_connected else 0
        balance_sepolia = web3_sepolia.eth.get_balance(user_address) if is_connected else 0

        return jsonify({
            'connected': is_connected,
            'mainnet_block_number': mainnet_block_number,
            'sepolia_block_number': sepolia_block_number,
            'balance_mainnet': web3.fromWei(balance_mainnet, 'ether'),
            'balance_sepolia': web3_sepolia.fromWei(balance_sepolia, 'ether')
        })
    return '', 403

@app.route('/query_data', methods=['GET', 'POST'])
def query_data():
    if 'username' in session and session['role'] == 'user':
        if request.method == 'POST':
            query = request.form['query']
            results = WaterData.query.filter(WaterData.color.contains(query)).all()
            return render_template('query_results.html', results=results)
        return render_template('query_data.html')
    return redirect(url_for('login'))

@app.route('/update_water_data/<int:data_id>', methods=['GET', 'POST'])
def update_water_data(data_id):
    if 'username' in session and session['role'] == 'user':
        data = WaterData.query.get_or_404(data_id)
        if request.method == 'POST':
            data.ph = float(request.form['ph'])
            data.color = request.form['color']
            data.acidity = float(request.form['acidity'])
            db.session.commit()
            flash('Data updated successfully.')
            return redirect(url_for('view_water_data'))
        return render_template('update_water_data.html', data=data)
    return redirect(url_for('login'))


@app.route('/delete_water_data/<int:data_id>', methods=['POST'])
def delete_water_data(data_id):
    if 'username' in session and session['role'] == 'user':
        data = WaterData.query.get_or_404(data_id)
        db.session.delete(data)
        db.session.commit()
        flash('Data deleted successfully.')
        return redirect(url_for('view_water_data'))
    return redirect(url_for('login'))

@app.route('/about_us')
def about_us():
    return render_template('about_us.html')

@app.route('/email_us')
def email_us():
    return render_template('email_us.html')

@app.route('/water_supply')
def water_supply():
    return render_template('water_supply.html')

@app.route('/water_demand')
def water_demand():
    return render_template('water_demand.html')

@app.route('/water_consumers')
def water_consumers():
    return render_template('water_consumers.html')

@app.route('/water_treatment')
def water_treatment():
    return render_template('water_treatment.html')

@app.route('/water_discharge')
def water_discharge():
    return render_template('water_discharge.html')


if __name__ == '__main__':
    app.run(debug=True)

from flask import Flask, render_template, redirect, url_for, request, session, flash, jsonify
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime
from web3 import Web3
import os

app = Flask(__name__)
app.secret_key = os.environ.get('SECRET_KEY', 'your_secret_key')  # Use environment variables for sensitive data
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///water_quality.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)
migrate = Migrate(app, db)

# Connect to Ethereum Mainnet and Sepolia Test Network
alchemy_url = "https://eth-mainnet.g.alchemy.com/v2/3OqltayCdWx7230AEE3WNjtBp-xdAqoN"
web3 = Web3(Web3.HTTPProvider(alchemy_url))

sepolia_rpc_url = "https://sepolia-testnet-rpc.com"
web3_sepolia = Web3(Web3.HTTPProvider(sepolia_rpc_url))


class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(150), unique=True, nullable=False)
    password = db.Column(db.String(150), nullable=False)
    role = db.Column(db.String(50), nullable=False)

class WaterData(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    ph = db.Column(db.Float, nullable=False)
    color = db.Column(db.String(100), nullable=False)
    acidity = db.Column(db.Float, nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    validated = db.Column(db.Boolean, default=False)
    validator_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=True)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)
    transaction_hash = db.Column(db.String(100), nullable=True)
    amount_sent = db.Column(db.Float, nullable=True)
    amount_received = db.Column(db.Float, nullable=True)

class Transaction(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    transaction_type = db.Column(db.String(50), nullable=False)
    amount = db.Column(db.Float, nullable=False)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        user = User.query.filter_by(username=username).first()
        if user and check_password_hash(user.password, password):
            session['user_id'] = user.id
            session['username'] = user.username
            session['role'] = user.role
            return redirect(url_for('dashboard'))
        else:
            flash('Invalid credentials')
    return render_template('login.html')

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        role = request.form['role']

        existing_user = User.query.filter_by(username=username).first()
        if existing_user:
            flash('Username already exists. Please choose a different one.')
            return render_template('signup.html')

        hashed_password = generate_password_hash(password, method='pbkdf2:sha256')
        new_user = User(username=username, password=hashed_password, role=role)
        db.session.add(new_user)
        db.session.commit()
        flash('Signup successful! Please login.')
        return redirect(url_for('login'))
    return render_template('signup.html')

@app.route('/dashboard')
def dashboard():
    if 'username' in session:
        items = WaterData.query.all()  # Fetch water data items
        return render_template(
            'dashboard.html',
            username=session['username'],
            role=session['role'],
            items=items  # Pass items to the template
        )
    return redirect(url_for('login'))



@app.route('/logout')
def logout():
    session.clear()  # Clear entire session
    return redirect(url_for('login'))

@app.route('/create_water_data', methods=['GET', 'POST'])
def create_water_data():
    if 'username' in session and session['role'] == 'user':
        if request.method == 'POST':
            ph = float(request.form['ph'])
            color = request.form['color']
            acidity = float(request.form['acidity'])
            negative_values = ph < 0 or acidity < 0

            new_data = WaterData(ph=ph, color=color, acidity=acidity, user_id=session['user_id'])
            db.session.add(new_data)
            db.session.commit()

            if negative_values:
                flash('Data created with negative values. You will need to pay a penalty if validated.')
            else:
                flash('Data created successfully. Awaiting validation.')

            return redirect(url_for('dashboard'))
        return render_template('create_water_data.html')
    return redirect(url_for('login'))

@app.route('/view_water_data')
def view_water_data():
    if 'username' in session and session['role'] == 'user':
        water_data = WaterData.query.filter_by(user_id=session['user_id']).all()
        transactions = Transaction.query.filter_by(user_id=session['user_id']).all()

        # Get validator information
        validator_usernames = {data.validator_id: User.query.get(data.validator_id).username for data in water_data if data.validator_id}

        return render_template('view_water_data.html', water_data=water_data, transactions=transactions, validator_usernames=validator_usernames)
    return redirect(url_for('login'))

@app.route('/manage_users')
def manage_users():
    if 'username' in session and session['role'] == 'admin':
        users = User.query.all()
        return render_template('manage_users.html', users=users)
    return redirect(url_for('login'))

@app.route('/validate_data')
def validate_data():
    if 'username' in session and session['role'] == 'government':
        water_data = WaterData.query.filter_by(validated=False).all()
        return render_template('validate_data.html', water_data=water_data)
    return redirect(url_for('login'))

@app.route('/validate_with_metamask', methods=['POST'])
def validate_with_metamask():
    data_id = request.form['data_id']
    data = WaterData.query.get(data_id)
    if data and not data.validated:
        # MetaMask validation logic
        transaction_hash = "0x..."  # Replace with actual transaction hash
        data.validated = True
        data.transaction_hash = transaction_hash
        db.session.commit()

        flash('Data validated successfully!')
    return redirect(url_for('validate_data'))

@app.route('/validate/<int:data_id>', methods=['POST'])
def validate(data_id):
    if 'username' in session and session['role'] == 'government':
        data = WaterData.query.get(data_id)
        if data and not data.validated:
            data.validated = True
            db.session.commit()
            flash('Data validated successfully!')
        return redirect(url_for('validate_data'))
    return redirect(url_for('login'))

@app.route('/apply_penalty', methods=['POST'])
def apply_penalty():
    data_id = request.form['data_id']
    data = WaterData.query.get(data_id)
    if data:
        user = User.query.get(data.user_id)
        # Logic for applying penalty
        flash('Penalty applied successfully!')
    return redirect(url_for('validate_data'))

@app.route('/check_connection')
def check_connection():
    connection_status = web3.isConnected()
    block_number = web3.eth.blockNumber
    balance = web3.eth.getBalance("0xYourAddress")  # Replace with actual address
    return jsonify({'connection_status': connection_status, 'block_number': block_number, 'balance': balance})

@app.route('/query_data', methods=['GET'])
def query_data():
    if 'username' in session and session['role'] == 'user':
        query = request.args.get('query')
        water_data = WaterData.query.filter(WaterData.ph.contains(query) | WaterData.color.contains(query)).all()
        return render_template('query_data.html', water_data=water_data)
    return redirect(url_for('login'))

@app.route('/update_water_data/<int:data_id>', methods=['GET', 'POST'])
def update_water_data(data_id):
    if 'username' in session and session['role'] == 'user':
        data = WaterData.query.get_or_404(data_id)
        if request.method == 'POST':
            data.ph = float(request.form['ph'])
            data.color = request.form['color']
            data.acidity = float(request.form['acidity'])
            db.session.commit()
            flash('Data updated successfully.')
            return redirect(url_for('view_water_data'))
        return render_template('update_water_data.html', data=data)
    return redirect(url_for('login'))



@app.route('/about_us')
def about_us():
    return render_template('about_us.html')

@app.route('/email_us')
def email_us():
    return render_template('email_us.html')

@app.route('/water_supply')
def water_supply():
    return render_template('water_supply.html')

@app.route('/water_demand')
def water_demand():
    return render_template('water_demand.html')

@app.route('/water_consumers')
def water_consumers():
    return render_template('water_consumers.html')

@app.route('/water_treatment')
def water_treatment():
    return render_template('water_treatment.html')

@app.route('/water_discharge')
def water_discharge():
    return render_template('water_discharge.html')

# Error Handlers
@app.errorhandler(404)
def page_not_found(e):
    return render_template('404.html'), 404

@app.errorhandler(500)
def internal_server_error(e):
    return render_template('500.html'), 500

if __name__ == '__main__':
    app.run(debug=True)

from flask import Flask, render_template, redirect, url_for, request, session, flash, jsonify
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime
from web3 import Web3
import os

app = Flask(__name__)
app.secret_key = os.environ.get('SECRET_KEY', 'your_secret_key')  # Use environment variables for sensitive data
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///water_quality.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)
migrate = Migrate(app, db)

# Connect to Ethereum Mainnet and Sepolia Test Network
alchemy_url = "https://eth-mainnet.g.alchemy.com/v2/3OqltayCdWx7230AEE3WNjtBp-xdAqoN"
web3 = Web3(Web3.HTTPProvider(alchemy_url))

sepolia_rpc_url = "https://sepolia-testnet-rpc.com"
web3_sepolia = Web3(Web3.HTTPProvider(sepolia_rpc_url))

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(150), unique=True, nullable=False)
    password = db.Column(db.String(150), nullable=False)
    role = db.Column(db.String(50), nullable=False)

class WaterData(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    ph = db.Column(db.Float, nullable=False)
    color = db.Column(db.String(100), nullable=False)
    acidity = db.Column(db.Float, nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    validated = db.Column(db.Boolean, default=False)
    validator_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=True)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)
    transaction_hash = db.Column(db.String(100), nullable=True)
    amount_sent = db.Column(db.Float, nullable=True)
    amount_received = db.Column(db.Float, nullable=True)

class Transaction(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    transaction_type = db.Column(db.String(50), nullable=False)
    amount = db.Column(db.Float, nullable=False)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        user = User.query.filter_by(username=username).first()
        if user and check_password_hash(user.password, password):
            session['user_id'] = user.id
            session['username'] = user.username
            session['role'] = user.role
            return redirect(url_for('dashboard'))
        else:
            flash('Invalid credentials')
    return render_template('login.html')

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        role = request.form['role']

        existing_user = User.query.filter_by(username=username).first()
        if existing_user:
            flash('Username already exists. Please choose a different one.')
            return render_template('signup.html')

        hashed_password = generate_password_hash(password, method='pbkdf2:sha256')
        new_user = User(username=username, password=hashed_password, role=role)
        db.session.add(new_user)
        db.session.commit()
        flash('Signup successful! Please login.')
        return redirect(url_for('login'))
    return render_template('signup.html')

@app.route('/dashboard')
def dashboard():
    if 'username' in session:
        items = WaterData.query.all()  # Fetch water data items
        return render_template(
            'dashboard.html',
            username=session['username'],
            role=session['role'],
            items=items  # Pass items to the template
        )
    return redirect(url_for('login'))

@app.route('/logout')
def logout():
    session.clear()  # Clear entire session
    return redirect(url_for('login'))

@app.route('/create_water_data', methods=['GET', 'POST'])
def create_water_data():
    if 'username' in session and session['role'] == 'user':
        if request.method == 'POST':
            ph = float(request.form['ph'])
            color = request.form['color']
            acidity = float(request.form['acidity'])
            negative_values = ph < 0 or acidity < 0

            new_data = WaterData(ph=ph, color=color, acidity=acidity, user_id=session['user_id'])
            db.session.add(new_data)
            db.session.commit()

            if negative_values:
                flash('Data created with negative values. You will need to pay a penalty if validated.')
            else:
                flash('Data created successfully. Awaiting validation.')

            return redirect(url_for('dashboard'))
        return render_template('create_water_data.html')
    return redirect(url_for('login'))

@app.route('/view_water_data')
def view_water_data():
    if 'username' in session and session['role'] == 'user':
        water_data = WaterData.query.filter_by(user_id=session['user_id']).all()
        transactions = Transaction.query.filter_by(user_id=session['user_id']).all()
        # Get validator information
        validator_usernames = {data.validator_id: User.query.get(data.validator_id).username for data in water_data if
                               data.validator_id}
        return render_template('view_water_data.html', water_data=water_data, transactions=transactions,
                               validator_usernames=validator_usernames)
    return redirect(url_for('login'))

@app.route('/manage_users')
def manage_users():
    if 'username' in session and session['role'] == 'admin':
        users = User.query.all()
        return render_template('manage_users.html', users=users)
    return redirect(url_for('login'))

@app.route('/validate_data')
def validate_data():
    if 'username' in session and session['role'] == 'government':
        water_data = WaterData.query.filter_by(validated=False).all()
        return render_template('validate_data.html', water_data=water_data)
    return redirect(url_for('login'))

@app.route('/validate_with_metamask', methods=['POST'])
def validate_with_metamask():
    data_id = request.form['data_id']
    data = WaterData.query.get(data_id)
    if data and not data.validated:
        # MetaMask validation logic
        transaction_hash = "0x..."  # Replace with actual transaction hash
        data.validated = True
        data.transaction_hash = transaction_hash
        db.session.commit()

        flash('Data validated successfully!')
    return redirect(url_for('validate_data'))

@app.route('/validate/<int:data_id>', methods=['POST'])
def validate(data_id):
    if 'username' in session and session['role'] == 'government':
        data = WaterData.query.get(data_id)
        if data and not data.validated:
            data.validated = True
            db.session.commit()
            flash('Data validated successfully!')
        return redirect(url_for('validate_data'))
    return redirect(url_for('login'))


@app.route('/apply_penalty', methods=['POST'])
def apply_penalty():
    data_id = request.form['data_id']
    data = WaterData.query.get(data_id)
    if data:
        user = User.query.get(data.user_id)
        # Logic for applying penalty
        flash('Penalty applied successfully!')
    return redirect(url_for('validate_data'))


@app.route('/check_connection')
def check_connection():
    connection_status = web3.isConnected()
    block_number = web3.eth.blockNumber
    balance = web3.eth.getBalance("0x776A1E56d80feC35C7b16476116C4257e061C223")  # Replace with actual address
    return jsonify({'connection_status': connection_status, 'block_number': block_number, 'balance': balance})

@app.route('/query_data', methods=['GET'])
def query_data():
    if 'username' in session and session['role'] == 'user':
        query = request.args.get('query')
        # If query is None or empty, return an empty list or handle appropriately
        if not query:
            water_data = []  # Return an empty list if no query is provided
        else:
            # Query water data where ph or color contains the query string
            water_data = WaterData.query.filter(
                WaterData.ph.contains(query) | WaterData.color.contains(query)
            ).all()
        return render_template('query_data.html', water_data=water_data)
    return redirect(url_for('login'))

@app.route('/update_water_data/<int:data_id>', methods=['GET', 'POST'])
def update_water_data(data_id):
    if 'username' in session and session['role'] == 'user':
        data = WaterData.query.get_or_404(data_id)
        if request.method == 'POST':
            data.ph = float(request.form['ph'])
            data.color = request.form['color']
            data.acidity = float(request.form['acidity'])
            db.session.commit()
            flash('Data updated successfully.')
            return redirect(url_for('view_water_data'))
        return render_template('update_water_data.html', data=data)
    return redirect(url_for('login'))


@app.route('/about_us')
def about_us():
    return render_template('about_us.html')


@app.route('/email_us')
def email_us():
    return render_template('email_us.html')


@app.route('/water_supply')
def water_supply():
    return render_template('water_supply.html')


@app.route('/water_demand')
def water_demand():
    return render_template('water_demand.html')


@app.route('/water_consumers')
def water_consumers():
    return render_template('water_consumers.html')

@app.route('/water_treatment')
def water_treatment():
    return render_template('water_treatment.html')

@app.route('/water_discharge')
def water_discharge():
    return render_template('water_discharge.html')

# Error Handlers
@app.errorhandler(404)
def page_not_found(e):
    return render_template('404.html'), 404

@app.errorhandler(500)
def internal_server_error(e):
    return render_template('500.html'), 500

if __name__ == '__main__':
    app.run(debug=True)

ALREADY GOOD CODE:

from flask import Flask, render_template, redirect, url_for, request, session, flash, jsonify
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime
from web3 import Web3
import os

app = Flask(__name__)
app.secret_key = os.environ.get('SECRET_KEY', 'your_secret_key')  # Use environment variables for sensitive data
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///water_quality.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)
migrate = Migrate(app, db)

# Connect to Ethereum Mainnet and Sepolia Test Network
alchemy_url = "https://eth-mainnet.g.alchemy.com/v2/3OqltayCdWx7230AEE3WNjtBp-xdAqoN"
web3 = Web3(Web3.HTTPProvider(alchemy_url))

sepolia_rpc_url = "https://sepolia-testnet-rpc.com"
web3_sepolia = Web3(Web3.HTTPProvider(sepolia_rpc_url))

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(150), unique=True, nullable=False)
    password = db.Column(db.String(150), nullable=False)
    role = db.Column(db.String(50), nullable=False)

class WaterData(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    ph = db.Column(db.Float, nullable=False)
    color = db.Column(db.String(100), nullable=False)
    acidity = db.Column(db.Float, nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    validated = db.Column(db.Boolean, default=False)
    validator_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=True)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)
    transaction_hash = db.Column(db.String(100), nullable=True)
    amount_sent = db.Column(db.Float, nullable=True)
    amount_received = db.Column(db.Float, nullable=True)

class Transaction(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    transaction_type = db.Column(db.String(50), nullable=False)
    amount = db.Column(db.Float, nullable=False)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        user = User.query.filter_by(username=username).first()
        if user and check_password_hash(user.password, password):
            session['user_id'] = user.id
            session['username'] = user.username
            session['role'] = user.role
            return redirect(url_for('dashboard'))
        else:
            flash('Invalid credentials')
    return render_template('login.html')

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        role = request.form['role']

        existing_user = User.query.filter_by(username=username).first()
        if existing_user:
            flash('Username already exists. Please choose a different one.')
            return render_template('signup.html')

        hashed_password = generate_password_hash(password, method='pbkdf2:sha256')
        new_user = User(username=username, password=hashed_password, role=role)
        db.session.add(new_user)
        db.session.commit()
        flash('Signup successful! Please login.')
        return redirect(url_for('login'))
    return render_template('signup.html')

@app.route('/dashboard')
def dashboard():
    if 'username' in session:
        items = WaterData.query.all()  # Fetch water data items
        return render_template(
            'dashboard.html',
            username=session['username'],
            role=session['role'],
            items=items  # Pass items to the template
        )
    return redirect(url_for('login'))

@app.route('/logout')
def logout():
    session.clear()  # Clear entire session
    return redirect(url_for('login'))

@app.route('/create_water_data', methods=['GET', 'POST'])
def create_water_data():
    if 'username' in session and session['role'] == 'user':
        if request.method == 'POST':
            ph = float(request.form['ph'])
            color = request.form['color']
            acidity = float(request.form['acidity'])
            negative_values = ph < 0 or acidity < 0

            new_data = WaterData(ph=ph, color=color, acidity=acidity, user_id=session['user_id'])
            db.session.add(new_data)
            db.session.commit()

            if negative_values:
                flash('Data created with negative values. You will need to pay a penalty if validated.')
            else:
                flash('Data created successfully. Awaiting validation.')

            return redirect(url_for('dashboard'))
        return render_template('create_water_data.html')
    return redirect(url_for('login'))

@app.route('/view_water_data')
def view_water_data():
    if 'username' in session and session['role'] == 'user':
        water_data = WaterData.query.filter_by(user_id=session['user_id']).all()
        transactions = Transaction.query.filter_by(user_id=session['user_id']).all()
        # Get validator information
        validator_usernames = {data.validator_id: User.query.get(data.validator_id).username for data in water_data if
                               data.validator_id}
        return render_template('view_water_data.html', water_data=water_data, transactions=transactions,
                               validator_usernames=validator_usernames)
    return redirect(url_for('login'))

@app.route('/manage_users')
def manage_users():
    if 'username' in session and session['role'] == 'admin':
        users = User.query.all()
        return render_template('manage_users.html', users=users)
    return redirect(url_for('login'))

@app.route('/validate_data')
def validate_data():
    if 'username' in session and session['role'] == 'government':
        water_data = WaterData.query.filter_by(validated=False).all()
        return render_template('validate_data.html', water_data=water_data)
    return redirect(url_for('login'))


@app.route('/validate_with_metamask', methods=['POST'])
def validate_with_metamask():
    data_id = request.form['data_id']
    data = WaterData.query.get(data_id)
    if data and not data.validated:
        # MetaMask validation logic here
        transaction_hash = "0x2f09f4d270762b0bdf96998264cdaab5e326aa36fbf83d2630e206e100f5accb"  # Replace with actual transaction hash
        data.validated = True
        data.transaction_hash = transaction_hash
        data.validator_id = session.get('user_id')  # Set the current user as the validator
        db.session.commit()

        flash('Data validated successfully!')
    return redirect(url_for('validate_data'))


@app.route('/validate/<int:data_id>', methods=['POST'])
def validate(data_id):
    if 'username' in session and session['role'] == 'government':
        data = WaterData.query.get(data_id)
        if data and not data.validated:
            data.validated = True
            data.validator_id = session.get('user_id')  # Set the current user as the validator
            db.session.commit()
            flash('Data validated successfully!')
        return redirect(url_for('validate_data'))
    return redirect(url_for('login'))


@app.route('/apply_penalty', methods=['POST'])
def apply_penalty():
    data_id = request.form['data_id']
    data = WaterData.query.get(data_id)
    if data:
        user = User.query.get(data.user_id)
        # Logic for applying penalty
        flash('Penalty applied successfully!')
    return redirect(url_for('validate_data'))

@app.route('/check_connection')
def check_connection():
    connection_status = web3.isConnected()
    block_number = web3.eth.blockNumber
    balance = web3.eth.getBalance("0x776A1E56d80feC35C7b16476116C4257e061C223")  
    return jsonify({'connection_status': connection_status, 'block_number': block_number, 'balance': balance})

@app.route('/query_data', methods=['GET'])
def query_data():
    if 'username' in session and session['role'] == 'user':
        query = request.args.get('query')
        # If query is None or empty, return an empty list or handle appropriately
        if not query:
            water_data = []  # Return an empty list if no query is provided
        else:
            # Query water data where ph or color contains the query string
            water_data = WaterData.query.filter(
                WaterData.ph.contains(query) | WaterData.color.contains(query)
            ).all()
        return render_template('query_data.html', water_data=water_data)
    return redirect(url_for('login'))

@app.route('/update_water_data/<int:data_id>', methods=['GET', 'POST'])
def update_water_data(data_id):
    if 'username' in session and session['role'] == 'user':
        data = WaterData.query.get_or_404(data_id)
        if request.method == 'POST':
            data.ph = float(request.form['ph'])
            data.color = request.form['color']
            data.acidity = float(request.form['acidity'])
            db.session.commit()
            flash('Data updated successfully.')
            return redirect(url_for('view_water_data'))
        return render_template('update_water_data.html', data=data)
    return redirect(url_for('login'))

@app.route('/about_us')
def about_us():
    return render_template('about_us.html')

@app.route('/email_us')
def email_us():
    return render_template('email_us.html')


@app.route('/water_supply')
def water_supply():
    return render_template('water_supply.html')


@app.route('/water_demand')
def water_demand():
    return render_template('water_demand.html')


@app.route('/water_consumers')
def water_consumers():
    return render_template('water_consumers.html')

@app.route('/water_treatment')
def water_treatment():
    return render_template('water_treatment.html')

@app.route('/water_discharge')
def water_discharge():
    return render_template('water_discharge.html')

# Error Handlers
@app.errorhandler(404)
def page_not_found(e):
    return render_template('404.html'), 404

@app.errorhandler(500)
def internal_server_error(e):
    return render_template('500.html'), 500


if __name__ == '__main__':
    app.run(debug=True)

    ALREADY GOOD

from flask import Flask, render_template, redirect, url_for, request, session, flash, jsonify
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime
from web3 import Web3
import os
import numpy as np
import pandas as pd
import torch
import joblib
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import io
import base64
import seaborn as sns

app = Flask(__name__)
app.secret_key = os.environ.get('SECRET_KEY', 'your_secret_key')
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///water_quality.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)
migrate = Migrate(app, db)

# Ethereum Network Connections
alchemy_url = "https://eth-mainnet.g.alchemy.com/v2/3OqltayCdWx7230AEE3WNjtBp-xdAqoN"
web3 = Web3(Web3.HTTPProvider(alchemy_url))
sepolia_rpc_url = "https://sepolia-testnet-rpc.com"
web3_sepolia = Web3(Web3.HTTPProvider(sepolia_rpc_url))

# Database Models
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(150), unique=True, nullable=False)
    password = db.Column(db.String(150), nullable=False)
    role = db.Column(db.String(50), nullable=False)

class WaterData(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    ph = db.Column(db.Float, nullable=False)
    color = db.Column(db.String(100), nullable=False)
    acidity = db.Column(db.Float, nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    validated = db.Column(db.Boolean, default=False)
    validator_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=True)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)
    transaction_hash = db.Column(db.String(100), nullable=True)
    amount_sent = db.Column(db.Float, nullable=True)
    amount_received = db.Column(db.Float, nullable=True)

class Transaction(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    transaction_type = db.Column(db.String(50), nullable=False)
    amount = db.Column(db.Float, nullable=False)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)

class PredictionHistory(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    ph = db.Column(db.Float, nullable=False)
    hardness = db.Column(db.Float, nullable=False)
    solids = db.Column(db.Float, nullable=False)
    chloramines = db.Column(db.Float, nullable=False)
    sulfate = db.Column(db.Float, nullable=False)
    conductivity = db.Column(db.Float, nullable=False)
    organic_carbon = db.Column(db.Float, nullable=False)
    trihalomethanes = db.Column(db.Float, nullable=False)
    turbidity = db.Column(db.Float, nullable=False)
    prediction_result = db.Column(db.String(50), nullable=False)
    prediction_confidence = db.Column(db.Float, nullable=False)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)

# Enhanced Machine Learning Model
class EnhancedTransformerModel(torch.nn.Module):
    def __init__(self, input_size, hidden_size=128, output_size=1, num_layers=3, nhead=4, dropout=0.2):
        super(EnhancedTransformerModel, self).__init__()
        self.encoder_layer = torch.nn.TransformerEncoderLayer(
            d_model=input_size,
            nhead=nhead,
            dim_feedforward=hidden_size,
            dropout=dropout,
            activation='gelu'
        )
        self.transformer_encoder = torch.nn.TransformerEncoder(
            self.encoder_layer,
            num_layers=num_layers
        )
        self.fc1 = torch.nn.Linear(input_size, hidden_size)
        self.fc2 = torch.nn.Linear(hidden_size, output_size)
        self.dropout = torch.nn.Dropout(dropout)
        self.layer_norm = torch.nn.LayerNorm(input_size)

    def forward(self, x):
        x = x.unsqueeze(1).transpose(0, 1)
        x = self.layer_norm(x)
        x = self.transformer_encoder(x)
        x = x[-1, :, :]
        x = torch.relu(self.fc1(x))
        x = self.dropout(x)
        return self.fc2(x)

class EnhancedWaterQualityPredictor:
    def __init__(self):
        self.model = None
        self.scaler = None
        self.features = [
            'ph', 'Hardness', 'Solids', 'Chloramines',
            'Sulfate', 'Conductivity', 'Organic_carbon',
            'Trihalomethanes', 'Turbidity'
        ]
        
    def initialize_model(self):
        try:
            self.model = torch.load('water_quality_model.pth', map_location=torch.device('cpu'))
            self.model.eval()
            self.scaler = joblib.load('scaler.pkl')
            return True
        except Exception as e:
            app.logger.error(f"Model initialization error: {e}")
            return False
    
    def predict(self, input_data):
        if not self.model or not self.scaler:
            if not self.initialize_model():
                return None, None
                
        try:
            input_values = [float(x) for x in input_data]
            if input_values[0] < 0 or input_values[0] > 14:  # pH validation
                return "Invalid pH (must be 0-14)", 0.0
                
            input_array = np.array(input_values).reshape(1, -1)
            scaled_input = self.scaler.transform(input_array)
            input_tensor = torch.tensor(scaled_input, dtype=torch.float32)
            
            with torch.no_grad():
                output = torch.sigmoid(self.model(input_tensor)).item()
                
            confidence = output if output > 0.5 else 1 - output
            return ("Potable" if output > 0.5 else "Not Potable", confidence * 100)
        except Exception as e:
            app.logger.error(f"Prediction error: {e}")
            return None, None

predictor = EnhancedWaterQualityPredictor()

def train_enhanced_model():
    try:
        data = pd.read_csv('water_potability.csv')
        data = data.dropna()
        data = data[(data['ph'] >= 0) & (data['ph'] <= 14)]
        data = data[data['Solids'] < 50000]
        
        X = data.iloc[:, :-1].values
        y = data.iloc[:, -1].values
        
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=0.2, random_state=42, stratify=y
        )
        
        scaler = StandardScaler()
        X_train_scaled = scaler.fit_transform(X_train)
        X_test_scaled = scaler.transform(X_test)
        
        model = EnhancedTransformerModel(
            input_size=9,
            hidden_size=128,
            output_size=1,
            num_layers=3,
            nhead=3,
            dropout=0.3
        )
        
        criterion = torch.nn.BCEWithLogitsLoss()
        optimizer = torch.optim.AdamW(model.parameters(), lr=0.0005, weight_decay=0.01)
        scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(optimizer, 'min', patience=5)
        
        X_train_tensor = torch.tensor(X_train_scaled, dtype=torch.float32)
        y_train_tensor = torch.tensor(y_train, dtype=torch.float32).view(-1, 1)
        X_test_tensor = torch.tensor(X_test_scaled, dtype=torch.float32)
        y_test_tensor = torch.tensor(y_test, dtype=torch.float32).view(-1, 1)
        
        best_loss = float('inf')
        patience = 10
        patience_counter = 0
        
        for epoch in range(200):
            model.train()
            optimizer.zero_grad()
            outputs = model(X_train_tensor)
            loss = criterion(outputs, y_train_tensor)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            optimizer.step()
            scheduler.step(loss)
            
            model.eval()
            with torch.no_grad():
                val_outputs = model(X_test_tensor)
                val_loss = criterion(val_outputs, y_test_tensor)
                val_preds = torch.sigmoid(val_outputs) > 0.5
                val_acc = (val_preds == y_test_tensor).float().mean()
                
            if epoch % 10 == 0:
                app.logger.info(f"Epoch {epoch}: Train Loss: {loss.item():.4f}, Val Loss: {val_loss.item():.4f}, Val Acc: {val_acc.item():.4f}")
            
            if val_loss < best_loss:
                best_loss = val_loss
                patience_counter = 0
                torch.save(model.state_dict(), 'best_model.pth')
            else:
                patience_counter += 1
                if patience_counter >= patience:
                    app.logger.info(f"Early stopping at epoch {epoch}")
                    break
        
        model.load_state_dict(torch.load('best_model.pth'))
        torch.save(model, 'water_quality_model.pth')
        joblib.dump(scaler, 'scaler.pkl')
        
        return True
    except Exception as e:
        app.logger.error(f"Training failed: {str(e)}")
        return False

# Application Routes
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        user = User.query.filter_by(username=username).first()
        if user and check_password_hash(user.password, password):
            session.update({
                'user_id': user.id,
                'username': user.username,
                'role': user.role
            })
            return redirect(url_for('dashboard'))
        flash('Invalid credentials')
    return render_template('login.html')

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        role = request.form['role']

        if User.query.filter_by(username=username).first():
            flash('Username already exists')
            return redirect(url_for('signup'))

        new_user = User(
            username=username,
            password=generate_password_hash(password, method='pbkdf2:sha256'),
            role=role
        )
        db.session.add(new_user)
        db.session.commit()
        flash('Registration successful! Please login.')
        return redirect(url_for('login'))
    return render_template('signup.html')

@app.route('/dashboard')
def dashboard():
    if 'username' not in session:
        return redirect(url_for('login'))
    return render_template('dashboard.html',
                         username=session['username'],
                         role=session['role'],
                         items=WaterData.query.all())

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login'))

@app.route('/create_water_data', methods=['GET', 'POST'])
def create_water_data():
    if 'username' not in session or session['role'] != 'user':
        return redirect(url_for('login'))
    
    if request.method == 'POST':
        ph = float(request.form['ph'])
        color = request.form['color']
        acidity = float(request.form['acidity'])
        negative_values = ph < 0 or acidity < 0

        new_data = WaterData(
            ph=ph,
            color=color,
            acidity=acidity,
            user_id=session['user_id']
        )
        db.session.add(new_data)
        db.session.commit()

        flash('Data created with negative values. Penalty may apply.' if negative_values 
              else 'Data created successfully. Awaiting validation.')
        return redirect(url_for('dashboard'))
    return render_template('create_water_data.html')

@app.route('/view_water_data')
def view_water_data():
    if 'username' not in session or session['role'] != 'user':
        return redirect(url_for('login'))
    
    water_data = WaterData.query.filter_by(user_id=session['user_id']).all()
    transactions = Transaction.query.filter_by(user_id=session['user_id']).all()
    validator_usernames = {
        data.validator_id: User.query.get(data.validator_id).username 
        for data in water_data if data.validator_id
    }
    return render_template('view_water_data.html', 
                         water_data=water_data,
                         transactions=transactions,
                         validator_usernames=validator_usernames)

@app.route('/manage_users')
def manage_users():
    if 'username' not in session or session['role'] != 'admin':
        return redirect(url_for('login'))
    return render_template('manage_users.html', users=User.query.all())

@app.route('/validate_data')
def validate_data():
    if 'username' not in session or session['role'] != 'government':
        return redirect(url_for('login'))
    return render_template('validate_data.html', 
                         water_data=WaterData.query.filter_by(validated=False).all())

@app.route('/validate_with_metamask', methods=['POST'])
def validate_with_metamask():
    if 'username' not in session or session['role'] != 'government':
        return redirect(url_for('login'))
    
    data_id = request.form['data_id']
    data = WaterData.query.get(data_id)
    if data and not data.validated:
        data.validated = True
        data.transaction_hash = "0x2f09f4d270762b0bdf96998264cdaab5e326aa36fbf83d2630e206e100f5accb"
        data.validator_id = session['user_id']
        db.session.commit()
        flash('Data validated successfully!')
    return redirect(url_for('validate_data'))

@app.route('/validate/<int:data_id>', methods=['POST'])
def validate(data_id):
    if 'username' not in session or session['role'] != 'government':
        return redirect(url_for('login'))
    
    data = WaterData.query.get(data_id)
    if data and not data.validated:
        data.validated = True
        data.validator_id = session['user_id']
        db.session.commit()
        flash('Data validated successfully!')
    return redirect(url_for('validate_data'))

@app.route('/apply_penalty', methods=['POST'])
def apply_penalty():
    if 'username' not in session or session['role'] != 'government':
        return redirect(url_for('login'))
    
    data_id = request.form['data_id']
    data = WaterData.query.get(data_id)
    if data:
        user = User.query.get(data.user_id)
        flash('Penalty applied successfully!')
    return redirect(url_for('validate_data'))

@app.route('/check_connection')
def check_connection():
    return jsonify({
        'connection_status': web3.isConnected(),
        'block_number': web3.eth.blockNumber,
        'balance': web3.eth.getBalance("0x776A1E56d80feC35C7b16476116C4257e061C223")
    })

@app.route('/query_data', methods=['GET'])
def query_data():
    if 'username' not in session or session['role'] != 'user':
        return redirect(url_for('login'))
    
    query = request.args.get('query', '')
    water_data = WaterData.query.filter(
        WaterData.ph.contains(query) | 
        WaterData.color.contains(query)
    ).all() if query else []
    return render_template('query_data.html', water_data=water_data)

@app.route('/update_water_data/<int:data_id>', methods=['GET', 'POST'])
def update_water_data(data_id):
    if 'username' not in session or session['role'] != 'user':
        return redirect(url_for('login'))
    
    data = WaterData.query.get_or_404(data_id)
    if request.method == 'POST':
        data.ph = float(request.form['ph'])
        data.color = request.form['color']
        data.acidity = float(request.form['acidity'])
        db.session.commit()
        flash('Data updated successfully.')
        return redirect(url_for('view_water_data'))
    return render_template('update_water_data.html', data=data)

@app.route('/predict_quality', methods=['GET', 'POST'])
def predict_quality():
    if 'username' not in session:
        return redirect(url_for('login'))
    
    result = None
    if request.method == 'POST':
        input_data = [request.form[feature] for feature in predictor.features]
        prediction, confidence = predictor.predict(input_data)
        
        if prediction:
            if not prediction.startswith("Invalid"):
                new_prediction = PredictionHistory(
                    user_id=session['user_id'],
                    ph=float(request.form['ph']),
                    hardness=float(request.form['Hardness']),
                    solids=float(request.form['Solids']),
                    chloramines=float(request.form['Chloramines']),
                    sulfate=float(request.form['Sulfate']),
                    conductivity=float(request.form['Conductivity']),
                    organic_carbon=float(request.form['Organic_carbon']),
                    trihalomethanes=float(request.form['Trihalomethanes']),
                    turbidity=float(request.form['Turbidity']),
                    prediction_result=prediction,
                    prediction_confidence=confidence
                )
                db.session.add(new_prediction)
                db.session.commit()
            result = (prediction, confidence)
        else:
            flash('Prediction failed')
    
    return render_template('predict_quality.html',
                         features=predictor.features,
                         result=result)

@app.route('/prediction_history')
def prediction_history():
    if 'username' not in session:
        return redirect(url_for('login'))
    
    history = PredictionHistory.query.filter_by(
        user_id=session['user_id']
    ).order_by(PredictionHistory.timestamp.desc()).all()
    return render_template('prediction_history.html', history=history)

@app.route('/quality_visualizations')
def quality_visualizations():
    if 'username' not in session:
        return redirect(url_for('login'))
    
    plots = {}
    try:
        data = pd.read_csv('water_potability.csv')
        data.fillna(data.median(), inplace=True)
        
        plt.figure(figsize=(10, 8))
        corr = data.corr()
        sns.heatmap(corr, annot=True, fmt=".2f", cmap='coolwarm')
        plt.title('Feature Correlation Heatmap')
        img = io.BytesIO()
        plt.savefig(img, format='png')
        img.seek(0)
        plots['correlation'] = base64.b64encode(img.getvalue()).decode()
        plt.close()
        
        distribution_plots = []
        for col in data.columns[:-1]:
            plt.figure()
            sns.histplot(data[col], kde=True)
            plt.title(f'Distribution of {col}')
            img = io.BytesIO()
            plt.savefig(img, format='png')
            img.seek(0)
            distribution_plots.append({
                'name': col,
                'image': base64.b64encode(img.getvalue()).decode()
            })
            plt.close()
        plots['distributions'] = distribution_plots
        
    except Exception as e:
        app.logger.error(f"Visualization error: {e}")
        flash('Error generating visualizations')
    
    return render_template('quality_visualizations.html', plots=plots)

@app.route('/admin/train_model')
def admin_train_model():
    if 'role' not in session or session['role'] != 'admin':
        flash('Unauthorized access')
        return redirect(url_for('login'))
    
    if train_enhanced_model():
        flash('Model trained successfully with improved accuracy!')
    else:
        flash('Model training failed')
    return redirect(url_for('dashboard'))

@app.route('/about_us')
def about_us():
    return render_template('about_us.html')

@app.route('/email_us')
def email_us():
    return render_template('email_us.html')

@app.route('/water_supply')
def water_supply():
    return render_template('water_supply.html')

@app.route('/water_demand')
def water_demand():
    return render_template('water_demand.html')

@app.route('/water_consumers')
def water_consumers():
    return render_template('water_consumers.html')

@app.route('/water_treatment')
def water_treatment():
    return render_template('water_treatment.html')

@app.route('/water_discharge')
def water_discharge():
    return render_template('water_discharge.html')

@app.errorhandler(404)
def page_not_found(e):
    return render_template('404.html'), 404

@app.errorhandler(500)
def internal_server_error(e):
    return render_template('500.html'), 500

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
        if not (os.path.exists('water_quality_model.pth') and 
                os.path.exists('scaler.pkl')):
            train_enhanced_model()
    app.run(debug=True)

'''

from flask import Flask, render_template, redirect, url_for, request, session, flash, jsonify
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime, timedelta
import os
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import joblib
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import io
import base64
import seaborn as sns
from functools import wraps
from web3 import Web3
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
from flask_talisman import Talisman
from werkzeug.middleware.proxy_fix import ProxyFix
import csv

# Initialize Flask app
app = Flask(__name__)
app.secret_key = os.environ.get('SECRET_KEY', 'your_secret_key_here')
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///water_quality.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['RATELIMIT_STORAGE_URL'] = 'memory://'  # Use Redis in production

# For handling proxy headers
app.wsgi_app = ProxyFix(app.wsgi_app, x_for=1, x_proto=1, x_host=1, x_prefix=1)

# Security headers
Talisman(app, force_https=False)

# Rate limiting
limiter = Limiter(
    app=app,
    key_func=get_remote_address,
    storage_uri=app.config['RATELIMIT_STORAGE_URL'],
    default_limits=["200 per day", "50 per hour"]
)

# Initialize extensions
db = SQLAlchemy(app)
migrate = Migrate(app, db)

# Initialize Web3 connections
try:
    alchemy_url = "https://eth-mainnet.g.alchemy.com/v2/3OqltayCdWx7230AEE3WNjtBp-xdAqoN"
    web3 = Web3(Web3.HTTPProvider(alchemy_url))
    if not web3.isConnected():
        app.logger.warning("Connected to Ethereum but not to mainnet")
except Exception as e:
    app.logger.error(f"Mainnet connection error: {str(e)}")
    web3 = None

try:
    sepolia_rpc_url = "https://sepolia-testnet-rpc.com"
    web3_sepolia = Web3(Web3.HTTPProvider(sepolia_rpc_url))
    if not web3_sepolia.isConnected():
        app.logger.warning("Connected to Ethereum but not to Sepolia testnet")
except Exception as e:
    app.logger.error(f"Sepolia connection error: {str(e)}")
    web3_sepolia = None

# Database Models
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(150), unique=True, nullable=False)
    password = db.Column(db.String(150), nullable=False)
    role = db.Column(db.String(50), nullable=False, default='user')
    wallet_address = db.Column(db.String(42), nullable=True)

class WaterData(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    ph = db.Column(db.Float, nullable=False)
    hardness = db.Column(db.Float, nullable=True)
    solids = db.Column(db.Float, nullable=True)
    chloramines = db.Column(db.Float, nullable=True)
    sulfate = db.Column(db.Float, nullable=True)
    conductivity = db.Column(db.Float, nullable=True)
    organic_carbon = db.Column(db.Float, nullable=True)
    trihalomethanes = db.Column(db.Float, nullable=True)
    turbidity = db.Column(db.Float, nullable=True)
    color = db.Column(db.String(100), nullable=True)
    acidity = db.Column(db.Float, nullable=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    validated = db.Column(db.Boolean, default=False)
    validator_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=True)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)
    transaction_hash = db.Column(db.String(100), nullable=True)
    penalty_amount = db.Column(db.Float, nullable=True)
    incentive_amount = db.Column(db.Float, nullable=True)
    amount_sent = db.Column(db.Float, nullable=True)
    amount_received = db.Column(db.Float, nullable=True)

class Transaction(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    validator_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    transaction_type = db.Column(db.String(50), nullable=False)
    amount = db.Column(db.Float, nullable=False)
    transaction_hash = db.Column(db.String(100), nullable=False)
    data_id = db.Column(db.Integer, db.ForeignKey('water_data.id'), nullable=True)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)

# Water Quality Predictor
class WaterQualityPredictor:
    def __init__(self):
        self.model = None
        self.scaler = None
        self.features = [
            'ph', 'hardness', 'solids', 'chloramines', 
            'sulfate', 'conductivity', 'organic_carbon',
            'trihalomethanes', 'turbidity'
        ]
        
    def initialize_model(self):
        try:
            self.model = torch.load('water_quality_model.pth', map_location=torch.device('cpu'))
            self.model.eval()
            self.scaler = joblib.load('scaler.pkl')
            return True
        except Exception as e:
            app.logger.error(f"Model initialization error: {e}")
            return False
    
    def predict(self, input_data):
        if not self.model or not self.scaler:
            if not self.initialize_model():
                return None, None
                
        try:
            input_values = [
                float(input_data['ph']),
                float(input_data['hardness']),
                float(input_data['solids']),
                float(input_data['chloramines']),
                float(input_data['sulfate']),
                float(input_data['conductivity']),
                float(input_data['organic_carbon']),
                float(input_data['trihalomethanes']),
                float(input_data['turbidity'])
            ]
            
            input_array = np.array(input_values).reshape(1, -1)
            scaled_input = self.scaler.transform(input_array)
            input_tensor = torch.tensor(scaled_input, dtype=torch.float32)
            
            with torch.no_grad():
                output = torch.sigmoid(self.model(input_tensor)).item()
                
            confidence = output if output > 0.5 else 1 - output
            return ("Potable" if output > 0.5 else "Not Potable", confidence * 100)
        except Exception as e:
            app.logger.error(f"Prediction error: {e}")
            return None, None

predictor = WaterQualityPredictor()

# Helper functions
def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            flash('Please log in to access this page', 'danger')
            return redirect(url_for('login', next=request.url))
        return f(*args, **kwargs)
    return decorated_function

def admin_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session or session.get('role') != 'admin':
            flash('Admin access required', 'danger')
            return redirect(url_for('login', next=request.url))
        return f(*args, **kwargs)
    return decorated_function

def government_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session or session.get('role') not in ['government', 'admin']:
            flash('Government access required', 'danger')
            return redirect(url_for('login', next=request.url))
        return f(*args, **kwargs)
    return decorated_function

def save_prediction_to_csv(user_id, username, input_data, prediction, confidence):
    try:
        with open('prediction_history.csv', 'a', newline='') as f:
            writer = csv.writer(f)
            writer.writerow([
                user_id,
                username,
                input_data['ph'],
                input_data['hardness'],
                input_data['solids'],
                input_data['chloramines'],
                input_data['sulfate'],
                input_data['conductivity'],
                input_data['organic_carbon'],
                input_data['trihalomethanes'],
                input_data['turbidity'],
                prediction,
                confidence,
                datetime.now().isoformat()
            ])
        return True
    except Exception as e:
        app.logger.error(f"Error saving prediction to CSV: {e}")
        return False

def get_user_predictions(user_id):
    try:
        with open('prediction_history.csv', 'r') as f:
            reader = csv.DictReader(f)
            return [row for row in reader if int(row['user_id']) == user_id]
    except Exception as e:
        app.logger.error(f"Error reading predictions from CSV: {e}")
        return []

def train_simplified_model():
    try:
        df = pd.read_csv("water_potability.csv").dropna()
        X = df[['ph', 'Hardness', 'Solids', 'Chloramines', 'Sulfate', 
               'Conductivity', 'Organic_carbon', 'Trihalomethanes', 'Turbidity']].values
        y = df['Potability'].values
        
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=0.2, random_state=42, stratify=y
        )
        
        scaler = StandardScaler()
        X_train_scaled = scaler.fit_transform(X_train)
        X_test_scaled = scaler.transform(X_test)
        
        model = nn.Sequential(
            nn.Linear(9, 128),
            nn.ReLU(),
            nn.Linear(128, 64),
            nn.ReLU(),
            nn.Linear(64, 32),
            nn.ReLU(),
            nn.Linear(32, 1)
        )
        
        criterion = nn.BCEWithLogitsLoss()
        optimizer = torch.optim.Adam(model.parameters(), lr=0.001)
        
        X_train_tensor = torch.tensor(X_train_scaled, dtype=torch.float32)
        y_train_tensor = torch.tensor(y_train, dtype=torch.float32).view(-1, 1)
        X_test_tensor = torch.tensor(X_test_scaled, dtype=torch.float32)
        y_test_tensor = torch.tensor(y_test, dtype=torch.float32).view(-1, 1)
        
        for epoch in range(200):
            optimizer.zero_grad()
            outputs = model(X_train_tensor)
            loss = criterion(outputs, y_train_tensor)
            loss.backward()
            optimizer.step()
            
            if epoch % 20 == 0:
                with torch.no_grad():
                    val_outputs = model(X_test_tensor)
                    val_preds = torch.sigmoid(val_outputs) > 0.5
                    val_acc = (val_preds == y_test_tensor).float().mean().item() * 100
                    app.logger.info(f"Epoch {epoch}: Loss: {loss.item():.4f}, Val Acc: {val_acc:.2f}%")
        
        torch.save(model, 'water_quality_model.pth')
        joblib.dump(scaler, 'scaler.pkl')
        return True
    except Exception as e:
        app.logger.error(f"Training failed: {str(e)}")
        return False

def initialize_database():
    with app.app_context():
        try:
            # Clear existing database
            db.drop_all()
            
            # Create all tables
            db.create_all()
            
            # Create admin user
            if not User.query.filter_by(username='admin').first():
                admin = User(
                    username='admin',
                    password=generate_password_hash('admin123'),
                    role='admin'
                )
                db.session.add(admin)
                db.session.commit()
            
            # Initialize model files
            if not (os.path.exists('water_quality_model.pth') and 
                    os.path.exists('scaler.pkl')):
                train_simplified_model()
                
        except Exception as e:
            app.logger.error(f"Database initialization failed: {str(e)}")
            db.session.rollback()

# Routes
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        user = User.query.filter_by(username=username).first()
        
        if user and check_password_hash(user.password, password):
            session['user_id'] = user.id
            session['username'] = user.username
            session['role'] = user.role
            flash('Login successful!', 'success')
            next_page = request.args.get('next', url_for('dashboard'))
            return redirect(next_page)
        flash('Invalid username or password', 'danger')
    return render_template('login.html')

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        confirm_password = request.form.get('confirm_password')
        role = request.form.get('role', 'user')

        if password != confirm_password:
            flash('Passwords do not match', 'danger')
            return redirect(url_for('signup'))

        if User.query.filter_by(username=username).first():
            flash('Username already exists', 'danger')
            return redirect(url_for('signup'))

        new_user = User(
            username=username,
            password=generate_password_hash(password, method='pbkdf2:sha256'),
            role=role
        )
        
        try:
            db.session.add(new_user)
            db.session.commit()
            flash('Registration successful! Please login.', 'success')
            return redirect(url_for('login'))
        except Exception as e:
            db.session.rollback()
            flash('Registration failed', 'danger')
            app.logger.error(f"Registration error: {e}")
    
    return render_template('signup.html')

@app.route('/dashboard')
@login_required
def dashboard():
    user = User.query.get(session['user_id'])
    try:
        predictions = len(get_user_predictions(user.id))
        validated = WaterData.query.filter_by(user_id=user.id, validated=True).count()
    except Exception as e:
        app.logger.error(f"Database error: {e}")
        predictions = 0
        validated = 0
    
    return render_template('dashboard.html',
                         username=session['username'],
                         role=session['role'],
                         predictions=predictions,
                         validated=validated,
                         is_government=user.role in ['government', 'admin'])

@app.route('/water_supply')
def water_supply():
    return 'water_supply.html'

@app.route('/water_consumers')
def water_consumers():
    return 'water_consumers.html'

@app.route('/water_treatment')
def water_treatment():
    return 'water_treatment.html'

@app.route('/water_demand')
def water_demand():
    return 'water_demand.html'

@app.route('/water_discharge')
def water_discharge():
    return 'water_discharge.html'

@app.route('/quality_visualizations')
def quality_visualizations():
    return 'quality_visualizations.html'

@app.route('/view_csv_data')
def view_csv_data():
    return 'view_csv_data.html'

@app.route('/about_us')
def about_us():
    return 'about_us.html'

@app.route('/contact_us')
def contact_us():
    return 'contact_us.html'

@app.route('/email_us')
def email_us():
    return 'email_us.html'

@app.route('/logout')
def logout():
    session.clear()
    flash('You have been logged out', 'info')
    return redirect(url_for('index'))

@app.route('/create_water_data', methods=['GET', 'POST'])
@login_required
def create_water_data():
    if request.method == 'POST':
        try:
            new_data = WaterData(
                ph=float(request.form.get('ph')),
                hardness=float(request.form.get('hardness')),
                solids=float(request.form.get('solids')),
                chloramines=float(request.form.get('chloramines')),
                sulfate=float(request.form.get('sulfate')),
                conductivity=float(request.form.get('conductivity')),
                organic_carbon=float(request.form.get('organic_carbon')),
                trihalomethanes=float(request.form.get('trihalomethanes')),
                turbidity=float(request.form.get('turbidity')),
                color=request.form.get('color', ''),
                acidity=float(request.form.get('acidity', 0)),
                user_id=session['user_id']
            )
            
            db.session.add(new_data)
            db.session.commit()
            flash('Water data submitted successfully!', 'success')
            return redirect(url_for('view_water_data'))
        except Exception as e:
            db.session.rollback()
            flash('Error submitting water data', 'danger')
            app.logger.error(f"Water data submission error: {e}")
    
    return render_template('create_water_data.html')

@app.route('/view_water_data')
@login_required
def view_water_data():
    water_data = WaterData.query.filter_by(user_id=session['user_id']).order_by(WaterData.timestamp.desc()).all()
    transactions = Transaction.query.filter_by(user_id=session['user_id']).order_by(Transaction.timestamp.desc()).all()
    
    validator_ids = {d.validator_id for d in water_data if d.validator_id}
    validator_usernames = {
        v.id: v.username 
        for v in User.query.filter(User.id.in_(validator_ids)).all()
    } if validator_ids else {}
    
    return render_template('view_water_data.html', 
                         water_data=water_data,
                         transactions=transactions,
                         validator_usernames=validator_usernames)

@app.route('/query_data', methods=['GET', 'POST'])
@login_required
def query_data():
    if request.method == 'POST':
        try:
            # Get filter parameters from the form
            start_date = request.form.get('start_date')
            end_date = request.form.get('end_date')
            min_ph = request.form.get('min_ph')
            max_ph = request.form.get('max_ph')
            potability = request.form.get('potability')
            validated_status = request.form.get('validated_status')
            
            # Build the base query
            query = WaterData.query.filter_by(user_id=session['user_id'])
            
            # Apply date filters
            if start_date:
                start_date = datetime.strptime(start_date, '%Y-%m-%d')
                query = query.filter(WaterData.timestamp >= start_date)
            if end_date:
                end_date = datetime.strptime(end_date, '%Y-%m-%d') + timedelta(days=1)
                query = query.filter(WaterData.timestamp <= end_date)
            
            # Apply pH filters
            if min_ph:
                query = query.filter(WaterData.ph >= float(min_ph))
            if max_ph:
                query = query.filter(WaterData.ph <= float(max_ph))
            
            # Apply potability filter (requires prediction)
            if potability and potability != 'all':
                # Get all data first
                all_data = query.all()
                
                # Filter based on prediction
                filtered_data = []
                for data in all_data:
                    input_data = {
                        'ph': data.ph,
                        'hardness': data.hardness,
                        'solids': data.solids,
                        'chloramines': data.chloramines,
                        'sulfate': data.sulfate,
                        'conductivity': data.conductivity,
                        'organic_carbon': data.organic_carbon,
                        'trihalomethanes': data.trihalomethanes,
                        'turbidity': data.turbidity
                    }
                    prediction, _ = predictor.predict(input_data)
                    if (potability == 'potable' and prediction == 'Potable') or \
                       (potability == 'not_potable' and prediction == 'Not Potable'):
                        filtered_data.append(data)
                
                water_data = filtered_data
            else:
                water_data = query.all()
            
            # Apply validation status filter
            if validated_status and validated_status != 'all':
                if validated_status == 'validated':
                    water_data = [d for d in water_data if d.validated]
                elif validated_status == 'not_validated':
                    water_data = [d for d in water_data if not d.validated]
            
            # Get validator usernames
            validator_ids = {d.validator_id for d in water_data if d.validator_id}
            validator_usernames = {
                v.id: v.username 
                for v in User.query.filter(User.id.in_(validator_ids)).all()
            } if validator_ids else {}
            
            return render_template('query_results.html',
                                water_data=water_data,
                                validator_usernames=validator_usernames,
                                filters=request.form)
            
        except Exception as e:
            app.logger.error(f"Query error: {e}")
            flash('Error querying water data', 'danger')
    
    # For GET requests or if there's an error
    return render_template('query_data.html')

@app.route('/predict_quality', methods=['GET', 'POST'])
@login_required
def predict_quality():
    if request.method == 'POST':
        try:
            input_data = {
                'ph': request.form.get('ph'),
                'hardness': request.form.get('hardness'),
                'solids': request.form.get('solids'),
                'chloramines': request.form.get('chloramines'),
                'sulfate': request.form.get('sulfate'),
                'conductivity': request.form.get('conductivity'),
                'organic_carbon': request.form.get('organic_carbon'),
                'trihalomethanes': request.form.get('trihalomethanes'),
                'turbidity': request.form.get('turbidity')
            }
            
            prediction, confidence = predictor.predict(input_data)
            
            if prediction:
                save_prediction_to_csv(
                    session['user_id'],
                    session['username'],
                    input_data,
                    prediction,
                    confidence
                )
                
                plt.figure(figsize=(12, 6))
                features = list(input_data.keys())
                values = [float(v) for v in input_data.values()]
                plt.bar(features, values)
                plt.title('Input Features Visualization')
                plt.ylabel('Value')
                plt.xticks(rotation=45)
                plt.tight_layout()
                
                img = io.BytesIO()
                plt.savefig(img, format='png', bbox_inches='tight')
                img.seek(0)
                plot_url = base64.b64encode(img.getvalue()).decode('utf-8')
                plt.close()
                
                return render_template('prediction_result.html',
                                    prediction=prediction,
                                    confidence=confidence,
                                    plot_url=plot_url)
            
        except Exception as e:
            flash('Error making prediction', 'danger')
            app.logger.error(f"Prediction error: {e}")
    
    return render_template('predict_quality.html')

@app.route('/prediction_history')
@login_required
def prediction_history():
    history = get_user_predictions(session['user_id'])
    return render_template('prediction_history.html', history=history)

@app.route('/analytics_dashboard')
@login_required
def analytics_dashboard():
    try:
        history = get_user_predictions(session['user_id'])
        
        if history:
            df = pd.DataFrame([{
                'ph': float(h['ph']),
                'hardness': float(h['hardness']),
                'solids': float(h['solids']),
                'chloramines': float(h['chloramines']),
                'sulfate': float(h['sulfate']),
                'conductivity': float(h['conductivity']),
                'organic_carbon': float(h['organic_carbon']),
                'trihalomethanes': float(h['trihalomethanes']),
                'turbidity': float(h['turbidity']),
                'prediction': h['prediction_result'],
                'confidence': float(h['prediction_confidence']),
                'timestamp': h['timestamp']
            } for h in history])
            
            accuracy = (df[df['confidence'] > 90].shape[0] / df.shape[0]) * 100
            avg_confidence = df['confidence'].mean()
            
            plots = {}
            
            plt.figure(figsize=(8, 6))
            df['prediction'].value_counts().plot(kind='bar', color=['green', 'red'])
            plt.title('Prediction Distribution')
            plt.ylabel('Count')
            img = io.BytesIO()
            plt.savefig(img, format='png', bbox_inches='tight')
            img.seek(0)
            plots['pred_dist'] = base64.b64encode(img.getvalue()).decode()
            plt.close()
            
            plt.figure(figsize=(8, 6))
            plt.hist(df['confidence'], bins=20, color='skyblue')
            plt.title('Confidence Distribution')
            plt.xlabel('Confidence (%)')
            plt.ylabel('Count')
            img = io.BytesIO()
            plt.savefig(img, format='png', bbox_inches='tight')
            img.seek(0)
            plots['conf_dist'] = base64.b64encode(img.getvalue()).decode()
            plt.close()
            
            return render_template('analytics.html',
                                accuracy=accuracy,
                                avg_confidence=avg_confidence,
                                total_predictions=len(df),
                                plots=plots)
        else:
            flash('No prediction history available', 'info')
            return redirect(url_for('dashboard'))
    except Exception as e:
        app.logger.error(f"Analytics error: {str(e)}")
        flash('Error generating analytics', 'danger')
        return redirect(url_for('dashboard'))

@app.route('/admin/train_model')
@admin_required
def admin_train_model():
    if train_simplified_model():
        flash('Model trained successfully with improved accuracy!', 'success')
    else:
        flash('Model training failed', 'danger')
    return redirect(url_for('dashboard'))

@app.errorhandler(404)
def page_not_found(e):
    return render_template('404.html'), 404

@app.errorhandler(500)
def internal_server_error(e):
    return render_template('500.html'), 500

if __name__ == '__main__':
    initialize_database()
    app.run(debug=True)
